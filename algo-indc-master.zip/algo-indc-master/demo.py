import numpy as np
from sklearn.metrics import mean_squared_error
from scipy.stats import pearsonr
# from run_model import getOLSModelDegree1, getOLSModelOneDegree2, getOLSModelTwoDegree2, getOLSModelDegree2, \
#     runStepwiseRegression, getMLresults, runDT, getMLresultsGBDT, getSubsampleResults
from run_model import getMLresults, runDT, getMLresultsGBDT, getSubsampleResults, getMLresultsRFLasso
from gen_data import genData
from plot import plotHist, plotDistribution
from utils import determineAxis
import matplotlib.pyplot as plt
import time

st = time.time()
# print ('########################## gen X from normal without correlation ##################################')
# noise_sigma = 0.7
# sampleX, sampleY, gt_coef = genData(genCore='normal',func='1',noise_sigma=noise_sigma,correlated=False)
#
# axis = determineAxis(sampleX,manifold='Isomap')
# ########################OLS Regression for 1-degree polynomials
# resY = getOLSModelDegree1(sampleX, sampleY)
# mse = mean_squared_error(sampleY, resY)
# print 'Deg-1 OLS MSE:'+str(mse)+'\n'
# pscr = pearsonr(sampleY, resY)
# print 'Deg-1 OLS Pearson Corr:'+str(pscr)+'\n'
# title = 'Deg-1 OLS results; noise sigma:'+str(noise_sigma)
# plotHist(resY,sampleY,title)
# plotDistribution(resY,sampleY,sampleX,title,manifold='determined',detX=axis,y_value='absolute')
# plotDistribution(resY,sampleY,sampleX,title,manifold='determined',detX=axis,y_value='residual')
#
# #######################OLS Regression for 2-degree polynomials
# getOLSModelOneDegree2(sampleX,sampleY,0.0001)
# getOLSModelTwoDegree2(sampleX,sampleY,0.0001)
# resY = getOLSModelDegree2(sampleX, sampleY)
# mse = mean_squared_error(sampleY, resY)
# print 'Deg-2 OLS MSE:'+str(mse)+'\n'
# pscr = pearsonr(sampleY, resY)
# print 'Deg-2 OLS Pearson Corr:'+str(pscr)+'\n'
# title = 'Deg-2 OLS results; noise sigma:'+str(noise_sigma)
# plotHist(resY,sampleY,title)
# plotDistribution(resY,sampleY,sampleX,title,manifold='determined',detX=axis,y_value='absolute')
# plotDistribution(resY,sampleY,sampleX,title,manifold='determined',detX=axis,y_value='residual')
#
# ########################Step-wise regression##################
# runStepwiseRegression(sampleX,sampleY)
#
# #################Linear Regresson on 2 second-order items, model in ['lasso','ridge','Linear','RandomForest']
# getMLresults(sampleX,sampleY,XFsize=5,Psize=7,manifold='determined',detX=axis,y_value='residual')
# runDT(sampleX,sampleY,manifold='determined',detX=axis,y_value='residual',DT_depth=5)
print ('########################## gen X from normal+correlation=-0.3 ##################################')
# np.random.seed(0)
noise_sigma = 0.7
sampleX, sampleY, gt_coef = genData(genCore='normal',func='1',noise_sigma=noise_sigma,correlated=True)

axis = determineAxis(sampleX,manifold='Isomap')
# ########################OLS Regression for 1-degree polynomials
# resY = getOLSModelDegree1(sampleX, sampleY)
# mse = mean_squared_error(sampleY, resY)
# print 'Deg-1 OLS MSE:'+str(mse)+'\n'
# pscr = pearsonr(sampleY, resY)
# print 'Deg-1 OLS Pearson Corr:'+str(pscr)+'\n'
# title = 'Deg-1 OLS results; noise sigma:'+str(noise_sigma)
# plotHist(resY,sampleY,title)
# plotDistribution(resY,sampleY,sampleX,title,manifold='determined',detX=axis,y_value='absolute')
# plotDistribution(resY,sampleY,sampleX,title,manifold='determined',detX=axis,y_value='residual')
#
# #######################OLS Regression for 2-degree polynomials
# getOLSModelOneDegree2(sampleX,sampleY,0.0001)
# getOLSModelTwoDegree2(sampleX,sampleY,0.0001)
# resY = getOLSModelDegree2(sampleX, sampleY)
# mse = mean_squared_error(sampleY, resY)
# print 'Deg-2 OLS MSE:'+str(mse)+'\n'
# pscr = pearsonr(sampleY, resY)
# print 'Deg-2 OLS Pearson Corr:'+str(pscr)+'\n'
# title = 'Deg-2 OLS results; noise sigma:'+str(noise_sigma)
# plotHist(resY,sampleY,title)
# plotDistribution(resY,sampleY,sampleX,title,manifold='determined',detX=axis,y_value='absolute')
# plotDistribution(resY,sampleY,sampleX,title,manifold='determined',detX=axis,y_value='residual')

########################Step-wise regression##################
# runStepwiseRegression(sampleX,sampleY)

#################Linear Regresson on 2 second-order items, model in ['lasso','ridge','Linear','RandomForest']
# getMLresults(sampleX,sampleY,XFsize=5,Psize=7,manifold='determined',detX=axis,y_value='residual')
# runDT(sampleX,sampleY,manifold='determined',detX=axis,y_value='residual',DT_depth=5)

#################Linear Regresson on 2 second-order items, model in ['lasso','ridge','Linear','Gradient Boosting']
getMLresultsGBDT(sampleX,sampleY,XFsize=5,Psize=7,manifold='determined',detX=axis,y_value='residual')

#################Linear Regresson on 2 second-order items with k non-overlapping subsamples,
#################model in ['lasso','RandomForest']
truerate = []
for k in range(2,51):
    truerate.append(getSubsampleResults(sampleX,sampleY,fold=k))

print("list of true positive rate for different num of folds:", truerate)

x = range(2,51)
y = truerate

plt.xlabel('number of subsamples: k')
plt.ylabel('True Positive Rate')
plt.plot(x,y)
plt.show()


print("Experiment Finished in %.3f seconds."% (time.time() - st) )