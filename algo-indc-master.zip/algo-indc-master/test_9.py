import numpy as np
from numpy.core._multiarray_umath import ndarray
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from plot import plotFeatureImportance
from scipy.stats import pearsonr
# from run_model import getOLSModelDegree1, getOLSModelOneDegree2, getOLSModelTwoDegree2, getOLSModelDegree2, \
#     runStepwiseRegression, getMLresults, runDT, getMLresultsGBDT, getSubsampleResults
from run_model import neuralNetFeatureImportance,getMLresults, runDT, getMLresultsGBDT, getSubsampleResults, \
    getMLresultsRFLassoOls,getMLresultsNewX, getMLresultsGBDTNewX,linearReg,lassoSubsample,rfLassoSubsample,\
    GBLassoSubsample,NNLassoSubsample,OLSDegree2ResultsVector,getRfRfresultsNewX,getLassoRfResultsNewX,\
    getLassoLassoResultsNewX
from gen_data import genData
from process_data import genLongX,xFullidx
from plot import plotHist, plotDistribution
from utils import determineAxis, paramsLasso,hamming
import matplotlib.pyplot as plt
import time

# Run linear regression on 11 features for original DGP and 4 DGP:
print ('########################## gen X from normal+correlation=-0.3 ##################################')
np.random.seed(42)
noise_sigma = 0.7
# Original DGP
linearReg(x_size=11, genCore='normal', func='1',noise_sigma=noise_sigma, correlated=True)

# DGP 1:
linearReg(x_size=11,func='variation1',noise_sigma=noise_sigma)

# DGP 2:
linearReg(x_size=12,genCore='normal2',func='variation2', noise_sigma=noise_sigma)

# DGP 3:
linearReg(func='variation3',noise_sigma=noise_sigma)

# DGP 4:
linearReg(func='variation4', noise_sigma=noise_sigma)