import numpy as np
import matplotlib.pyplot as plt
from sklearn.manifold import Isomap, MDS, SpectralEmbedding, LocallyLinearEmbedding
from mpl_toolkits.mplot3d import Axes3D
from sklearn.ensemble import GradientBoostingRegressor
from seaborn import heatmap
import seaborn as sns

def plotHist(resY,sampleY,t):
    left = int(np.floor(np.min([np.min(resY),np.min(sampleY)])))
    right = int(np.ceil(np.max([np.max(resY),np.max(sampleY)])))
    resHist, resBin_edges = np.histogram(resY, density=False)
    sampleHist, sampleBin_edges = np.histogram(sampleY, density=False)
    top = np.max([resHist,sampleHist])
    ax1 = plt.subplot(1,2,1)
    plt.hist(sampleY, bins='auto')
    plt.xlim(left, right)
    plt.ylim(top=top)
    plt.title('Original data')
    ax2 = plt.subplot(1,2,2)
    plt.hist(resY, bins='auto')
    plt.xlim(left, right)
    plt.ylim(top=top)
    plt.title(t)
    plt.show()


def plotDistribution(resY, sampleY, sampleX, t, manifold='Isomap', detX=None, y_value='absolute'):
    if manifold == 'determined':
        X_transposed = detX
    else:
        if manifold == 'Isomap':
            embedding = Isomap(n_components=2)
        if manifold == 'MDS':
            embedding = MDS(n_components=2)
        if manifold == 'SpectralEmbedding':
            embedding = SpectralEmbedding(n_components=2)
        if manifold == 'LocallyLinearEmbedding':
            embedding = LocallyLinearEmbedding(n_components=2)
        X_transformed = embedding.fit_transform(sampleX)
        X_transposed = np.transpose(X_transformed)
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    if y_value == 'residual':
        resY = np.array(resY)
        sampleY = np.array(sampleY)
        resY -= sampleY
        for c, m, Y, l in [('g', 's', resY, 'residual')]:
            xs = X_transposed[0]
            ys = X_transposed[1]
            zs = Y
            ax.scatter(xs, ys, zs, c=c, marker=m, label=l)
            ax.set_xlabel('Factor-1 Label')
            ax.set_ylabel('Facotr-2 Label')
            ax.set_zlabel('predY-GT')
    else:
        for c, m, Y, l in [('r', 'o', resY, 'result'), ('b', '^', sampleY, 'ground-truth')]:
            xs = X_transposed[0]
            ys = X_transposed[1]
            zs = Y
            ax.scatter(xs, ys, zs, c=c, marker=m, label=l)
            ax.set_xlabel('Factor-1 Label')
            ax.set_ylabel('Facotr-2 Label')
            ax.set_zlabel('Value of Y')
    plt.title(t + '-' + y_value)
    plt.legend(loc='center right', prop={'size': '8'})
    plt.show()

def plotPredIntervalGBDT(trainX, trainY, testX, testY, pred):
    # Plot prediction intervals for Gradient Boosting Regression
    alpha = 0.95
    clf_quantile = GradientBoostingRegressor(
        **{'n_estimators': 100, 'learning_rate': 0.1, 'max_depth': 1, 'random_state': 0, 'loss': 'quantile'})
    clf_quantile.fit(trainX, trainY)
    pred_upper = clf_quantile.predict(testX)
    clf_quantile.set_params(alpha=1.0 - alpha)
    clf_quantile.fit(trainX, trainY)
    pred_lower = clf_quantile.predict(testX)
    plt.title('Prediction Intervals for Gradient Boosting Regression')
    plt.plot(range(len(trainX)), testY, 'b.', markersize=5, label=u'Observations')
    plt.plot(range(len(trainX)), pred, 'r-', label=u'Prediction')
    plt.plot(range(len(trainX)), pred_upper, 'k-')
    plt.plot(range(len(trainX)), pred_lower, 'k-')
    plt.fill(np.concatenate([range(len(trainX)), range(len(trainX))[::-1]]),
             np.concatenate([pred_upper, pred_lower[::-1]]),
             alpha=.5, fc='b', ec='None', label='90% prediction interval')
    plt.ylim(-6, 6)
    plt.ylabel('Y')
    plt.xlabel('Index of observation')
    plt.legend(loc='upper left')
    plt.show()


# Plot training deviance
# compute test set deviance
def plotDevianceGBDT(params, clf, testX, testY):
    test_score = np.zeros(params['n_estimators'], dtype=np.float64)
    for i, y_pred in enumerate(clf.staged_predict(testX)):
        test_score[i] = clf.loss_(testY, y_pred)
    plt.title('Deviance')
    plt.plot(range(params['n_estimators']), clf.train_score_, 'b-',
             label='Training Set Deviance')
    plt.plot(range(params['n_estimators']), test_score, 'r-',
             label='Test Set Deviance')
    plt.legend(loc='upper right')
    plt.xlabel('Boosting Iterations')
    plt.ylabel('Deviance')
    plt.show()


# Plot relative feature importance
# make importances relative to max importance
def plotRelFeatureImportance(imprt, features, model = 'Gradient Boosting'):
    feature_importance = 100.0 * (imprt / imprt.max())
    sorted_idx = np.argsort(feature_importance)
    pos = np.arange(sorted_idx.shape[0]) + .5
    plt.barh(pos, feature_importance[sorted_idx], align='center')
    plt.yticks(pos, features[sorted_idx])
    plt.xlabel('Relative Importance')
    plt.title(model + ' Feature Importance')
    plt.show()

# Plot feature importance
def plotFeatureImportance(testX, imprt, model='gradient boosting'):
    plt.bar(range(np.array(testX).shape[1]), imprt)
    plt.xlabel('Features')
    plt.title('Feature importance of ' + model)
    plt.show()


# Plot lasso coef heat map
def plotHeatmap(coef,xticks=[],yticks=[], xticklabel='subsample'):
    # yticks = []
    # for i in range(coef.shape[0]):
    #     yticks.append(i+1)
    xticks = []
    for i in range(coef.shape[1]):
        xticks.append(xticklabel + '%d'%(i+1))
    cmap = sns.diverging_palette(240, 10, n=14, sep=37,as_cmap=True)
    ax = sns.heatmap(coef,vmax=0.7,vmin=-0.7 ,cmap=cmap,
                 xticklabels=xticks,yticklabels=yticks,cbar=False)
    ax.set_yticklabels(ax.get_yticklabels(), rotation=0)
    hmap = ax.collections[0]
    cmap = plt.gcf().colorbar(hmap)
    cmap.set_ticks([-0.7,-0.6,-0.5,-0.4,-0.3,-0.2,-0.1,0,0.1,0.2,0.3,0.4,0.5,0.6])
    plt.ylabel('Features coefficients')
    plt.show()



