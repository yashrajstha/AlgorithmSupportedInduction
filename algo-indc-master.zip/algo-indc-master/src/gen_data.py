import numpy as np
from scipy.linalg import eigh, cholesky
from pylab import plot, show, axis, subplot, xlabel, ylabel, grid, title
# from typing import List, Any


def genX(data_size=11,genCore='random'):
    x = [0 for i in range(data_size)]
    if genCore == 'random':
        x[-1] = np.random.randint(2)
        x[0] = np.random.rand(1)[0]
        x[1],x[2] = np.random.randint(6),np.random.randint(6)
        for i in range(3,data_size-1):
            x[i] = np.random.rand(1)[0]
    elif genCore == 'normal':
        x[-1] = np.random.randint(2)
        x[0] = np.random.normal(0,1)
        #x[1],x[2] = np.random.randint(6),np.random.randint(6)
        for i in range(1,data_size-1):
            #x[i] = float(np.random.randint(6))/5
            x[i] = np.random.normal(0,1)
    elif genCore =='normal2':
        x[-1] = np.random.normal(0,1)
        x[-2] = np.random.randint(2)
        for i in range(data_size-2):
            #x[i] = float(np.random.randint(6))/5
            x[i] = np.random.normal(0,1)
    elif genCore == 'rnormal':
        x[-1] = np.random.randint(2)
        for i in range(0,data_size-1):
            tmp = np.random.normal(2.5,0.8)
            if tmp < 0:
                tmp = 0
            elif tmp > 5:
                tmp = 5
            else:
                tmp = np.round(tmp)
            x[i] = float(tmp)/5
    return np.array(x)


def genY(b,x,func='1',noise_sigma=1):
    if func == '1':
        b10 = b[:11]
        y = np.sum(b10*x)+b[11]*x[0]*x[2]+b[12]*x[1]*x[2]
    if func == '2':
        b10 = b[:11]
        y = (1-x[10])*(np.sum(b10*x)+b[11]*x[0]*x[2]+b[12]*x[1]*x[2])
        y += x[10]*(np.sum(b10*x)+b[12]*x[0]*x[2])
    if func == 'variation1':
        b10 = b[:11]
        y = np.sum(b10 * x) + b[11] * x[0] * x[0] + b[12] * x[1] * x[2]
    if func == 'variation2':
        b10 =b[:11]
        y = np.sum(b10 * x[:11]) + b[11]*x[0]*x[2]+b[12]*x[1]*x[2] + b[13]*x[11]
    if func == 'variation3':
        b10 = b[:11]
        y = np.sum(b10 * x) + b[11] * x[0] ** 3 + b[12] * x[1] * x[2]
    if func == 'variation4':
        b10 = b[:11]
        y = np.sum(b10 * x)
    if noise_sigma:
        err = np.random.normal(0, noise_sigma)
        y += err
    return y


def genCorrX(inputX,corr=0.3,rd=True, sample_size = 10000):
    std1 = np.std(inputX[0])
    std2 = np.std(inputX[1])
    means = [inputX[0].mean(), inputX[1].mean()]
    stds = [inputX[0].std(), inputX[1].std()]
    covs = [[stds[0]**2          , stds[0]*stds[1]*corr],
            [stds[0]*stds[1]*corr,           stds[1]**2]]
    res = np.random.multivariate_normal(means, covs, sample_size).T
    rounded = np.zeros_like(res)
    for i in range(len(res[0])):
        if rd:
            rounded[1][i] = np.round(res[1][i])
            if res[1][i] > 5:
                rounded[1][i] = 5
            if res[1][i] < 0:
                rounded[1][i] = 0
        else:
            rounded[1][i] = res[1][i]
        rounded[0][i] = res[0][i]
    subplot(1,3,1)
    plot(inputX[0],inputX[1], 'r.')
    title('original data')
    xlabel('x0')
    ylabel('x5')
    grid(True)
    subplot(1,3,2)
    plot(res[0],res[1], 'b.')
    title('correlated data')
    xlabel('x0')
    ylabel('x5')
    grid(True)
    subplot(1,3,3)
    plot(rounded[0],rounded[1], 'b.')
    title('rounded data')
    xlabel('x0')
    ylabel('x5')
    grid(True)
    show()
    return rounded


def genData(hyperparams={'alpha':0.4,'beta':0.2,'gamma':0.5,'delta':-0.3,'theta':-0.7, 'rho':0.1},
            x_size=11,sample_size=1000,func='1',genCore='random',noise_sigma=1,correlated=False,b5=0):
    sampleX = []
    sampleY = []
    if genCore == 'normal2':
        b = [0 for i in range(x_size + 2)]
        if b5 != 0:
            b[5] = b5
        b[0] = hyperparams['alpha']
        b[1] = hyperparams['beta']
        b[2] = hyperparams['gamma']
        b[13] = hyperparams['rho']
        b[-3] = hyperparams['delta']
        b[-2] = hyperparams['theta']
    else:
        b = [0 for i in range(x_size + 2)]
        if b5 != 0:
            b[5] = b5
        b[0] = hyperparams['alpha']
        b[1] = hyperparams['beta']
        b[2] = hyperparams['gamma']
        b[-2] = hyperparams['delta']
        b[-1] = hyperparams['theta']
    b = np.array(b)
    for i in range(sample_size):
        x = genX(x_size,genCore)
        sampleX += [list(x)]
    if correlated:
        x_transposed = np.transpose(sampleX)
        #tmp = [x_transposed[0],x_transposed[2]]
        tmp = [x_transposed[0], x_transposed[5]]
        res = genCorrX(tmp,corr=-0.3,rd=False, sample_size=sample_size)
        res_transposed = np.transpose(res)
        for i in range(len(sampleX)):
            sampleX[i][0] = res_transposed[i][0]
            sampleX[i][5] = res_transposed[i][1]
    if func != 'variation4':
        for i in range(sample_size):
            y = genY(b, sampleX[i], func=func, noise_sigma=noise_sigma)
            if correlated:
                y += -0.3 * sampleX[i][0] * sampleX[i][5]
            sampleY += [y]
    else:
        for i in range(sample_size):
            y = genY(b, sampleX[i], func=func, noise_sigma=noise_sigma)
            sampleY += [y]
    return sampleX, sampleY, b

def genNewX(testX,largest_coef):
    res = []
    for i in range(len(testX)):
        tmp = []
        for c in largest_coef:
            if isinstance(c, int):
                tmp += [testX[i][c]]
            else:
                tmp += [testX[i][c[0]]*testX[i][c[1]]]
        res += [tmp]
    return res


def parseIntegers(mixedList):
    return [x for x in mixedList if type(x) == int]

# This function aims to modify the genNewX function to include extra degree one terms from
# intersection terms.
def genNewXmodified(testX,largest_coef):
    res = []
    for i in range(len(testX)):
        tmp = []
        intIdx = parseIntegers(largest_coef)
        for c in largest_coef:
            if isinstance(c, int):
                tmp += [testX[i][c]]
            else:
                tmp += [testX[i][c[0]]*testX[i][c[1]]]
                if c[0] not in intIdx:
                    tmp += [testX[i][c[0]]]
                    intIdx += [c[0]]
                if c[1] not in intIdx:
                    tmp += [testX[i][c[1]]]
                    intIdx += [c[1]]
        res += [tmp]
    intIdx = parseIntegers(largest_coef)
    olsTerm = []
    for c in largest_coef:
        if isinstance(c, int):
            olsTerm += [c]
        else:
            olsTerm += [c]
            if c[0] not in intIdx:
                olsTerm += [c[0]]
                intIdx += [c[0]]
            if c[1] not in intIdx:
                olsTerm += [c[1]]
                intIdx += [c[1]]
    print "Terms for OLS are: " + str(olsTerm) + '\n'
    return [res, olsTerm]


