from __future__ import division
import numpy as np
import itertools
import matplotlib.pyplot as plt

from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
import statsmodels.api as sm
from sklearn.model_selection import train_test_split, KFold
from scipy.stats import pearsonr
from sklearn.tree import DecisionTreeRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error
import tqdm
from sklearn.utils import resample
from sklearn import linear_model

from keras.models import *
from keras.layers import *

#from demo import axis
from gen_data import genNewX, genNewXmodified, genData
from plot import plotHist, plotDistribution, plotPredIntervalGBDT, plotDevianceGBDT, plotRelFeatureImportance, \
    plotFeatureImportance, plotHeatmap

from process_data import genLongX, getLassoCoef
from utils import computeFeatureSelection, showRegression, printDT, computeFeatureSelectionNewLasso, paramsLasso
from rpy2 import robjects
from rpy2.robjects import FloatVector
from rpy2.robjects.packages import importr
from utils import determineAxis


def getMLresults(sampleX,sampleY,XFsize=3,Psize=5,manifold='Isomap',detX=None,y_value='absolute', noise_sigma=None):

    trainX, testX, trainY, testY = train_test_split(sampleX, sampleY, test_size=0.5, random_state=72)
    if detX.any() and manifold=='determined':
        _, detX1 = train_test_split(np.transpose(detX), test_size=0.5,random_state=72)
        detX1 = np.transpose(detX1)
    else:
        detX1 = detX
    clf = RandomForestRegressor()
    clf.fit(trainX,trainY)
    ## the importance of feature x[0] to x[10], an array of 11 elements
    imprt = clf.feature_importances_
    simprt = sorted(clf.feature_importances_,reverse=True)
    tmp = simprt[XFsize]
    ### change random forest into gradient boosting regression
    # clf = GradientBoostingRegressor(n_estimators=100, learning_rate=0.1, max_depth=1, random_state=0, loss='ls')
    # clf.fit(trainX, trainY)
    # imprt = clf.feature_importances_
    # simprt = sorted(imprt, reverse=True)
    # tmp = simprt[XFsize]
    XFidx = []
    for i in range(len(imprt)):
        if imprt[i] > tmp:
            XFidx += [i]
            ## XFidx stores the index of top XFsize features
    #print 'index in XF set: '+str(XFidx)
    print 'idx of features selected by Random Forest: '+ str(XFidx)
    comb = list(itertools.combinations_with_replacement(XFidx,2))
    overallidx = XFidx+comb  ## the list of indx of degree one and degree two features, the list has int and tuples
    ## get XFset as all degree one term and degree two terms from XFidx set
    XFset = []
    for i in range(len(trainX)):
        tmp = []
        ## select all degree one term in XFidx
        for j in XFidx:
            tmp += [trainX[i][j]]
        ## add all the degree two term of features with respect to XFidx
        for c in comb:
            tmp += [trainX[i][c[0]]*trainX[i][c[1]]]
        XFset += [tmp]
    ## run lasso, ridge, linear to XFset respectively
    for m in ['lasso','ridge','linear']:
        ## largest_coef stores a list of selcted features idx of given model
        largest_coef = computeFeatureSelection(XFset,trainY,top=Psize,model=m)
        print 'top '+str(Psize)+' largest absolute coef in model '+m+':\n'
        items = []  ## list of idx
        for i in range(len(largest_coef)):
            items += [overallidx[largest_coef[i]]]
            print 'the '+str(overallidx[largest_coef[i]])+'-th variable in trainX\n'
        ## select corresponding features data from original X train and X test
        pX = genNewX(trainX,items)
        tX = genNewX(testX,items)
        ## fit selcted features train data to ols
        model = sm.OLS(trainY,pX)
        results = model.fit()
        p_val = results.pvalues
        print(results.summary())
        parameters = results.params
        # compute prediction Y for test X
        resY = []
        for line in tX:
            resY += [np.dot(parameters,line)]
        # compute test error
        from sklearn.metrics import mean_squared_error
        mse = mean_squared_error(testY, resY)
        print m+' MSE:'+str(mse)+'\n'
        pscr = pearsonr(testY, resY)
        print m+' Pearson Corr:'+str(pscr)+'\n'
        title = 'RandomForest-'+m+' results; noise sigma:'+str(noise_sigma)
        plotHist(resY,testY,title)
        title = m+'-RandomForest results; noise sigma:'+str(noise_sigma)
        if y_value == 'residual':
            plotDistribution(resY,testY,tX,title,manifold=manifold,detX=detX1,y_value='absolute')
        plotDistribution(resY,testY,tX,title,manifold=manifold,detX=detX1,y_value=y_value)


# This function runs neural net work on sample data to return an array of feature importance
def neuralNetFeatureImportance(sampleX, sampleY, XFsize=5, Psize=7):
    trainX, testX, trainY, testY = train_test_split(sampleX, sampleY, test_size=0.5, random_state=72)
    features = np.array(['Weakness of IP protection (X1)', 'Advertising intensity (X2)', 'R and D intensity (X3)',
                         'SGA expenses (X4)', 'Employee satisfaction (X5)', 'Litigation intensity (X6)',
                         'Employee diversity (X7)', 'Proportion of TMT with science degrees (X8)',
                         'Size (employees) (X9)',
                         'Age of company (X10)', 'CEO appeared in WSJ (X11)', 'X12'])
    # Build neural network architecture
    inp = Input(shape=(np.array(trainX).shape[1],))
    x = Dense(128, activation='relu')(inp)
    x = Dense(32, activation='relu')(x)
    out = Dense(1)(x)
    model = Model(inp, out)
    model.compile(optimizer='adam', loss='mse')
    # Fit neural network on training data
    model.fit(np.array(trainX), np.array(trainY),epochs=100, batch_size=128)
    # Predict error on test data
    unscaledPred = model.predict(np.array(testX))
    MAE = mean_absolute_error(testY, unscaledPred)
    print 'MAE for neural network with original data: ' + str(MAE) + '\n'
    # Compute permutation and scoring for each feature
    np.random.seed(33)
    final_score = []
    for i in range(np.array(testX).shape[1]):
        shuff_test = np.array(testX)
        shuff_test[:,i] = np.random.permutation(shuff_test[:,i])
        shuff_unscaledPred = model.predict(shuff_test)
        score = mean_absolute_error(shuff_unscaledPred, testY)
        final_score.append(score)
    final_score = np.array(final_score)
    print 'The final score: ' + str(final_score)
    # Plot feature importance
    plt.bar(range(np.array(testX).shape[1]), (final_score - MAE) / MAE * 100)
    plt.xlabel('Features')
    plt.title('Feature importance of permutation based neural network')
    plt.show()
    imprt = final_score
    # Plot relative feature importance
    # make importances relative to max importance
    plotRelFeatureImportance(imprt, features, model='Neural Network')
    simprt = sorted(final_score, reverse=True)
    tmp = simprt[XFsize]
    XFidx = []
    for i in range(len(imprt)):
        if imprt[i] > tmp:
            XFidx += [i]
            # XFidx stores the index of top XFsize features
    print 'idx of features selected by neural network: ' + str(XFidx)
    comb = list(itertools.combinations_with_replacement(XFidx, 2))
    overallidx = XFidx + comb  ## the list of indx of degree one and degree two features, the list has int and tuples
    ## get XFset as all degree one term and degree two terms from XFidx set
    XFset = []
    for i in range(len(trainX)):
        tmp = []
        ## select all degree one term in XFidx
        for j in XFidx:
            tmp += [trainX[i][j]]
        ## add all the degree two term of features with respect to XFidx
        for c in comb:
            tmp += [trainX[i][c[0]] * trainX[i][c[1]]]
        XFset += [tmp]
    ## run lasso, ridge, linear to XFset respectively
    for m in ['lasso', 'ridge', 'linear']:
        ## largest_coef stores a list of selcted features idx of given model
        largest_coef = computeFeatureSelection(XFset, trainY, top=Psize, model=m)
        print 'top ' + str(Psize) + ' largest absolute coef in model ' + m + ':\n'
        items = []  ## list of idx
        for i in range(len(largest_coef)):
            items += [overallidx[largest_coef[i]]]
            print 'the ' + str(overallidx[largest_coef[i]]) + '-th variable in trainX\n'
        ## select corresponding features data from original X train and X test
        pX = genNewXmodified(trainX, items)[0]
        tX = genNewXmodified(testX, items)[0]
        ## fit selcted features train data to ols
        model = sm.OLS(trainY, pX)
        results = model.fit()
        # p_val = results.pvalues
        print(results.summary())
        print '\n' + 'residual MSE: ' + str(results.mse_resid)
        parameters = results.params
        ## select features after ols based on pvalue
        firstOlsTerm = genNewXmodified(trainX, items)[1]
        p_val = results.pvalues
        sigtermIdx = []
        for i, pvalue in enumerate(p_val):
            if pvalue < 0.01:
                sigtermIdx.append(i)
        # print("index after ols:", sigtermIdx)
        olsFeature = np.array(firstOlsTerm)[sigtermIdx]
        print "features selected after Ols Model(1) based on pvalue:" + str(olsFeature)
        # Run second ols after drop insignificant terms
        secondOlsX = genNewXmodified(trainX, olsFeature)[0]
        results2 = sm.OLS(trainY, secondOlsX).fit()
        print(results2.summary())
        print '\n' + 'residual MSE: ' + str(results2.mse_resid)
        print '\n'
        # Fit model(2) to test data
        print "OLS Results for deductive sample: " + '\n'
        deductiveX = genNewXmodified(testX, olsFeature)[0]
        results3 = sm.OLS(testY, deductiveX).fit()
        print(results3.summary())
        print '\n' + 'residual MSE: ' + str(results3.mse_resid)


# This function modifies getMLresults to include extra one degree terms in the ols after lasso
def getMLresultsNewX(sampleX,sampleY,XFsize=3,Psize=5,Pvalue=0.01):
    trainX, testX, trainY, testY = train_test_split(sampleX, sampleY, test_size=0.5, random_state=72)
    features = np.array(['Weakness of IP protection (X1)', 'Advertising intensity (X2)', 'R and D intensity (X3)',
                'SGA expenses (X4)', 'Employee satisfaction (X5)', 'Litigation intensity (X6)',
                'Employee diversity (X7)', 'Proportion of TMT with science degrees (X8)', 'Size (employees) (X9)',
                'Age of company (X10)', 'CEO appeared in WSJ (X11)', 'X12'])
    clf = RandomForestRegressor()
    clf.fit(trainX,trainY)
    pred = clf.predict(testX)
    MSE = mean_squared_error(testY, pred)
    print 'MSE for random forest: ' + str(MSE) + '\n'
    # The importance of feature x[0] to x[10], an array of 11 elements
    imprt = clf.feature_importances_
    # Plot relative feature importance
    # make importances relative to max importance
    plotRelFeatureImportance(imprt, features, model='Random Forest')
    # Plot feature importance
    plotFeatureImportance(testX, imprt, model='random forest')
    simprt = sorted(clf.feature_importances_,reverse=True)
    tmp = simprt[XFsize]
    XFidx = []
    for i in range(len(imprt)):
        if imprt[i] > tmp:
            XFidx += [i]
            # XFidx stores the index of top XFsize features
    print 'idx of features selected by Random Forest: '+ str(XFidx)
    comb = list(itertools.combinations_with_replacement(XFidx,2))
    overallidx = XFidx+comb  ## the list of indx of degree one and degree two features, the list has int and tuples
    ## get XFset as all degree one term and degree two terms from XFidx set
    XFset = []
    for i in range(len(trainX)):
        tmp = []
        ## select all degree one term in XFidx
        for j in XFidx:
            tmp += [trainX[i][j]]
        ## add all the degree two term of features with respect to XFidx
        for c in comb:
            tmp += [trainX[i][c[0]]*trainX[i][c[1]]]
        XFset += [tmp]
    ## run lasso, ridge, linear to XFset respectively
    for m in ['lasso','ridge','linear']:
        ## largest_coef stores a list of selcted features idx of given model
        largest_coef = computeFeatureSelectionNewLasso(XFset,trainY,top=Psize,model=m)
        print 'top '+str(Psize)+' largest absolute coef in model '+m+':\n'
        items = []  ## list of idx
        for i in range(len(largest_coef)):
            items += [overallidx[largest_coef[i]]]
            print 'the '+str(overallidx[largest_coef[i]])+'-th variable in trainX\n'
        ## select corresponding features data from original X train and X test
        pX = genNewXmodified(trainX,items)[0]
        tX = genNewXmodified(testX,items)[0]
        ## fit selcted features train data to ols
        model = sm.OLS(trainY,pX)
        results = model.fit()
        # p_val = results.pvalues
        print(results.summary())
        print '\n' + 'residual MSE: ' + str(results.mse_resid)
        parameters = results.params
        ## select features after ols based on pvalue
        firstOlsTerm = genNewXmodified(trainX,items)[1]
        p_val = results.pvalues
        sigtermIdx = []
        for i, pvalue in enumerate(p_val):
            if pvalue < 0.01:
                sigtermIdx.append(i)
        # print("index after ols:", sigtermIdx)
        olsFeature = np.array(firstOlsTerm)[sigtermIdx]
        print "features selected after Ols Model(1) based on pvalue:" + str(olsFeature)
        # Run second ols after drop insignificant terms
        secondOlsX = genNewXmodified(trainX, olsFeature)[0]
        results2 = sm.OLS(trainY, secondOlsX).fit()
        print(results2.summary())
        print '\n' + 'residual MSE: ' + str(results2.mse_resid)
        print '\n'
        # Fit model(2) to test data
        print "OLS Results for deductive sample: " + '\n'
        deductiveX = genNewXmodified(testX,olsFeature)[0]
        decOlsTerms = genNewXmodified(testX,olsFeature)[1]
        results3 = sm.OLS(testY, deductiveX).fit()
        print(results3.summary())
        print '\n' + 'residual MSE: ' + str(results3.mse_resid)
        p_val2 = results3.pvalues
        sigtermIdx2 = []
        for i, pvalue in enumerate(p_val2):
            if pvalue < Pvalue:
                sigtermIdx2.append(i)
        # print("index after ols:", sigtermIdx)
        olsFeature2 = np.array(decOlsTerms)[sigtermIdx2]
        print "features selected after Ols Model on deductive sample based on pvalue:" + str(olsFeature2)
        return olsFeature2

# This function modifies getMLresultsGBDT to include extra one degree terms in the ols after lasso
def getMLresultsGBDTNewX(sampleX,sampleY,XFsize=3,Psize=5):
    trainX, testX, trainY, testY = train_test_split(sampleX, sampleY, test_size=0.5, random_state=72)
    features = np.array(['Weakness of IP protection (X1)', 'Advertising intensity (X2)', 'R and D intensity (X3)',
                         'SGA expenses (X4)', 'Employee satisfaction (X5)', 'Litigation intensity (X6)',
                         'Employee diversity (X7)', 'Proportion of TMT with science degrees (X8)',
                         'Size (employees) (X9)',
                         'Age of company (X10)', 'CEO appeared in WSJ (X11)', 'X12'])
    params = {'n_estimators': 100, 'learning_rate': 0.1, 'max_depth':1, 'random_state':0, 'loss':'ls'}
    clf = GradientBoostingRegressor(**params)
    clf.fit(trainX, trainY)
    pred = clf.predict(testX)
    MSE = mean_squared_error(testY, pred)
    print 'MSE for gradient descent: ' + str(MSE) + '\n'
    # The importance of feature x[0] to x[10], an array of 11 elements
    imprt = clf.feature_importances_

    # Plot prediction intervals for Gradient Boosting Regression
    plotPredIntervalGBDT(trainX, trainY, testX, testY,pred)

    # Plot training deviance
    # compute test set deviance
    plotDevianceGBDT(params,clf, testX, testY)

    # Plot relative feature importance
    # make importances relative to max importance
    plotRelFeatureImportance(imprt, features, model='Gradient Boosting')

    # Plot feature importance
    plotFeatureImportance(testX, imprt, model='gradient boosting')


    simprt = sorted(clf.feature_importances_, reverse=True)
    tmp = simprt[XFsize]
    XFidx = []
    for i in range(len(imprt)):
        if imprt[i] > tmp:
            XFidx += [i]
            # XFidx stores the index of top XFsize features
    print 'idx of features selected by Gradient Boosting: ' + str(XFidx)
    comb = list(itertools.combinations_with_replacement(XFidx, 2))
    overallidx = XFidx + comb  ## the list of indx of degree one and degree two features, the list has int and tuples
    ## get XFset as all degree one term and degree two terms from XFidx set
    XFset = []
    for i in range(len(trainX)):
        tmp = []
        ## select all degree one term in XFidx
        for j in XFidx:
            tmp += [trainX[i][j]]
        ## add all the degree two term of features with respect to XFidx
        for c in comb:
            tmp += [trainX[i][c[0]] * trainX[i][c[1]]]
        XFset += [tmp]
    ## run lasso, ridge, linear to XFset respectively
    for m in ['lasso', 'ridge', 'linear']:
        ## largest_coef stores a list of selcted features idx of given model
        largest_coef = computeFeatureSelectionNewLasso(XFset, trainY, top=Psize, model=m)
        print 'top ' + str(Psize) + ' largest absolute coef in model ' + m + ':\n'
        items = []  ## list of idx
        for i in range(len(largest_coef)):
            items += [overallidx[largest_coef[i]]]
            print 'the ' + str(overallidx[largest_coef[i]]) + '-th variable in trainX\n'
        ## select corresponding features data from original X train and X test
        pX = genNewXmodified(trainX, items)[0]
        tX = genNewXmodified(testX, items)[0]
        ## fit selcted features train data to ols
        model = sm.OLS(trainY, pX)
        results = model.fit()
        # p_val = results.pvalues
        print(results.summary())
        print '\n' + 'residual MSE: ' + str(results.mse_resid)
        parameters = results.params
        ## select features after ols based on pvalue
        firstOlsTerm = genNewXmodified(trainX, items)[1]
        p_val = results.pvalues
        sigtermIdx = []
        for i, pvalue in enumerate(p_val):
            if pvalue < 0.01:
                sigtermIdx.append(i)
        # print("index after ols:", sigtermIdx)
        olsFeature = np.array(firstOlsTerm)[sigtermIdx]
        print "features selected after Ols Model(1) based on pvalue:" + str(olsFeature)
        # Run second ols after drop insignificant terms
        secondOlsX = genNewXmodified(trainX, olsFeature)[0]
        results2 = sm.OLS(trainY, secondOlsX).fit()
        print(results2.summary())
        print '\n' + 'residual MSE: ' + str(results2.mse_resid)
        print '\n'
        # Fit model(2) to test data
        print "OLS Results for deductive sample: " + '\n'
        deductiveX = genNewXmodified(testX, olsFeature)[0]
        results3 = sm.OLS(testY, deductiveX).fit()
        print(results3.summary())
        print '\n' + 'residual MSE: ' + str(results3.mse_resid)


# This function define a new getMLresults function using gradient boosting
def getMLresultsGBDT(sampleX,sampleY,XFsize=3,Psize=5,manifold='Isomap',detX=None,y_value='absolute', noise_sigma=None):

    trainX, testX, trainY, testY = train_test_split(sampleX, sampleY, test_size=0.5, random_state=72)
    if detX.any() and manifold=='determined':
        _, detX1 = train_test_split(np.transpose(detX), test_size=0.5,random_state=72)
        detX1 = np.transpose(detX1)
    else:
        detX1 = detX
    ### change random forest into gradient boosting regression
    clf = GradientBoostingRegressor(n_estimators=100, learning_rate=0.1, max_depth=1, random_state=0, loss='ls')
    clf.fit(trainX, trainY)
    imprt = clf.feature_importances_
    simprt = sorted(imprt, reverse=True)
    tmp = simprt[XFsize]
    XFidx = []
    for i in range(len(imprt)):
        if imprt[i] > tmp:
            XFidx += [i]
            ## XFidx stores the index of top XFsize features
    #print 'index in XF set: '+str(XFidx)
    print 'idx of features selected by GBDT: '+ str(XFidx)
    comb = list(itertools.combinations_with_replacement(XFidx,2))
    overallidx = XFidx+comb  ## the list of indx of degree one and degree two features, the list has int and tuples
    ## get XFset as all degree one term and degree two terms from XFidx set
    XFset = []
    for i in range(len(trainX)):
        tmp = []
        ## select all degree one term in XFidx
        for j in XFidx:
            tmp += [trainX[i][j]]
        ## add all the degree two term of features with respect to XFidx
        for c in comb:
            tmp += [trainX[i][c[0]]*trainX[i][c[1]]]
        XFset += [tmp]
    ## run lasso, ridge, linear to XFset respectively
    for m in ['lasso','ridge','linear']:
        ## largest_coef stores a list of selcted features idx of given model
        largest_coef = computeFeatureSelection(XFset,trainY,top=Psize,model=m)
        print 'top '+str(Psize)+' largest absolute coef in model '+m+':\n'
        items = []  ## list of idx
        for i in range(len(largest_coef)):
            items += [overallidx[largest_coef[i]]]
            print 'the '+str(overallidx[largest_coef[i]])+'-th variable in trainX\n'
        ## select corresponding features data from original X train and X test
        pX = genNewX(trainX,items)
        tX = genNewX(testX,items)
        ## fit selcted features train data to ols
        model = sm.OLS(trainY,pX)
        results = model.fit()
        p_val = results.pvalues
        print(results.summary())
        parameters = results.params
        # compute prediction Y for test X
        resY = []
        for line in tX:
            resY += [np.dot(parameters,line)]
        # compute test error
        from sklearn.metrics import mean_squared_error
        mse = mean_squared_error(testY, resY)
        print m+' MSE:'+str(mse)+'\n'
        pscr = pearsonr(testY, resY)
        print m+' Pearson Corr:'+str(pscr)+'\n'
        title = 'RandomForest-'+m+' results; noise sigma:'+str(noise_sigma)
        plotHist(resY,testY,title)
        title = m+'-RandomForest results; noise sigma:'+str(noise_sigma)
        if y_value == 'residual':
            plotDistribution(resY,testY,tX,title,manifold=manifold,detX=detX1,y_value='absolute')
        plotDistribution(resY,testY,tX,title,manifold=manifold,detX=detX1,y_value=y_value)





def getOLSModelDegree1(sampleX, sampleY):
    print 'OLSModel for all degree 1 variables:\n'
    model = sm.OLS(sampleY,sampleX)
    results = model.fit()
    p_val = results.pvalues
    print(results.summary())
    parameters = results.params
    resY = []
    for line in sampleX:
        resY += [np.dot(parameters,line)]
    return np.array(resY)


def getOLSModelOneDegree2(sampleX,sampleY,plim=0.01,verbose=False):
    print 'OLSModel for ONE degree 2 variables:\n'
    comb2_list = list(itertools.combinations_with_replacement(range(len(sampleX[0])),2))
    res = []
    countBigger10 = {}
    deg2pval = {}
    for comb in comb2_list:
        x = []
        count_p_val = 0
        for i in range(len(sampleX)):
            tmp = []
            tmp += sampleX[i]
            tmp += [sampleX[i][comb[0]]*sampleX[i][comb[1]]]
            x += [tmp]
        #X = sm.add_constant(x)
        model = sm.OLS(sampleY,x)
        results = model.fit()
        p_val = results.pvalues
        for i in range(len(p_val)):
            if p_val[i] <= plim:
                count_p_val += 1
        #print 'one combination of:'+str(comb)+' get '+str(count_p_val)+' p-vals <= 0.01\n'
        res += [count_p_val]
        if p_val[-1] <= plim:
            deg2pval[comb] = p_val[-1]
        if count_p_val > 10:
            countBigger10[comb] = count_p_val
    res_sort = sorted(res,reverse=True)
    print 'Top p-val combination:\n'
    print str(comb2_list[res.index(res_sort[0])])+', with '+\
    str(res[res.index(res_sort[0])])+' p-vals <= '+str(plim)+'\n'
    #print 'combination that has more than 10 p-vals <= 0.01:\n'+str(countBigger10)+'\n'
    print str(len(deg2pval.keys()))+\
    ' combinations that have a deg-2 item with p value <= '+\
    str(plim)
    if verbose:
        print str(deg2pval.keys())+'\n'
    else:
        print 'set verbose=True to view\n'


def getOLSModelTwoDegree2(sampleX,sampleY,plim=0.01,verbose=False):
    print 'OLSModel for Two degree 2 variables:\n'
    comb2_list = list(itertools.combinations_with_replacement(range(len(sampleX[0])),2))
    combcomb2_list = list(itertools.combinations_with_replacement(comb2_list,2))
    res = []
    countBigger10 = {}
    deg2pval = {}
    deg2pvalNew = {}
    for comb in combcomb2_list:
        x = []
        count_p_val = 0
        for i in range(len(sampleX)):
            tmp = []
            tmp += sampleX[i]
            tmp += [sampleX[i][comb[0][0]]*sampleX[i][comb[0][1]]]
            tmp += [sampleX[i][comb[1][0]]*sampleX[i][comb[1][1]]]
            x += [tmp]
        #print len(x[0])
        #X = sm.add_constant(x)
        model = sm.OLS(sampleY,x)
        results = model.fit()
        p_val = results.pvalues
        for i in range(len(p_val)):
            if p_val[i] <= 0.01:
                count_p_val += 1
        res += [count_p_val]
        if p_val[-1] <= 0.01 or p_val[-2] <= 0.01:
            deg2pval[comb] = (p_val[-2],p_val[-1])
        if p_val[-1] <= 0.01 and p_val[-2] <= 0.01:
            deg2pvalNew[comb] = (p_val[-2],p_val[-1])
        if count_p_val > 12:
            countBigger10[comb] = count_p_val
    res_sort = sorted(res,reverse=True)
    print 'Top p-val combination:\n'
    for i in range(1):
        print str(combcomb2_list[res.index(res_sort[i])])+', with '+\
        str(res[res.index(res_sort[i])])+' p-vals <= '+str(plim)+'\n'
    #print 'combination that has more than 12 p-vals <= 0.01:\n'+str(countBigger10)+'\n'
    print str(len(deg2pvalNew.keys()))+\
    ' combinations that have BOTH TWO deg-2 item with p value <= '+\
    str(plim)+'\n'
    if verbose:
        print str(deg2pvalNew.keys())+'\n'
    else:
        print 'set verbose=True to view\n'
    print str(len(deg2pval.keys()))+\
    ' combinations that have at least ONE deg-2 item with p value <= '+\
    str(plim)+':\n'
    if verbose:
        print str(deg2pval.keys())+'\n'
    else:
        print 'set verbose=True to view\n'


def getOLSModelDegree2(sampleX, sampleY):
    print 'OLSModel for all degree 2 variables:\n'
    x = genLongX(sampleX)
    model = sm.OLS(sampleY,x)
    results = model.fit()
    p_val = results.pvalues
    p_val_sort = sorted(p_val)
    #for i in range(10):
        #print 'p-val:'+str(p_val_sort[i])+' at '+str(list(p_val).index(p_val_sort[i]))+'-th variable'
    comb2_list = list(itertools.combinations_with_replacement(range(len(sampleX[0])),2))
    print 'Corresponding Xs:\n'
    for i in range(len(comb2_list)):
        print 'X'+str(comb2_list[i])+':'+str(i)
    print(results.summary())
    parameters = results.params
    resY = []
    for line in x:
        resY += [np.dot(parameters,line)]
    return np.array(resY)


def runStepwiseRegression(sampleX,sampleY):
    stats = importr('stats')
    base = importr('base')
    model_string = 'y~'
    comb2_list = list(itertools.combinations_with_replacement(range(len(sampleX[0])),2))
    for i in range(len(sampleX[0])):
        model_string += 'X'+str(i)+'+'
    for c in comb2_list:
        tmp = 'X'+str(c[0])+'*X'+str(c[1])
        model_string += tmp+'+'
    model_string = model_string[:-1]
    print model_string
    sample_X_trans = np.transpose(sampleX)
    robjects.globalenv['X0'] = FloatVector(sample_X_trans[0])
    robjects.globalenv['X1'] = FloatVector(sample_X_trans[1])
    robjects.globalenv['X2'] = FloatVector(sample_X_trans[2])
    robjects.globalenv['X3'] = FloatVector(sample_X_trans[3])
    robjects.globalenv['X4'] = FloatVector(sample_X_trans[4])
    robjects.globalenv['X5'] = FloatVector(sample_X_trans[5])
    robjects.globalenv['X6'] = FloatVector(sample_X_trans[6])
    robjects.globalenv['X7'] = FloatVector(sample_X_trans[7])
    robjects.globalenv['X8'] = FloatVector(sample_X_trans[8])
    robjects.globalenv['X9'] = FloatVector(sample_X_trans[9])
    robjects.globalenv['X10'] = FloatVector(sample_X_trans[10])
    robjects.globalenv['y'] = FloatVector(sampleY)
    limodel = stats.lm(model_string)
    print (stats.step(limodel))
    return None

# This function runs decision trees on test data
def runDT(sampleX,sampleY,manifold='Isomap',detX=None,y_value='absolute',DT_depth=3, noise_sigma=None):
    X_train, X_test, y_train, y_test = train_test_split(sampleX, sampleY, test_size=0.5,random_state=42)
    if detX.any():
        _, detX1 = train_test_split(np.transpose(detX), test_size=0.5,random_state=42)
        detX1 = np.transpose(detX1)
    else:
        detX1 = detX

    ### decision tree regression: non ensemble version of random forest
    regressor = DecisionTreeRegressor(max_depth=DT_depth)
    regressor.fit(X_train,y_train)
    ## branches is the most import 4 features selected by Decision Tree
    branches = printDT(regressor)
    #export_graphviz(regressor,out_file=dot_data, filled=True, rounded=True,special_characters=True)
    comb_list = list(itertools.combinations_with_replacement(list(branches),2))
    print '4 most important Xs:'+str(branches)+'\n comb list:'+str(comb_list)

    ### generate new x_train x_test data with features interactions
    x_train = []
    x_test = []
    for i in range(len(X_train)):
        tmp = []
        tmp += X_train[i]
        for comb in comb_list:
            tmp += [X_train[i][comb[0]]*X_train[i][comb[1]]]
        x_train += [tmp]
    for i in range(len(X_test)):
        tmp = []
        tmp += X_test[i]
        for comb in comb_list:
            tmp += [X_test[i][comb[0]]*X_test[i][comb[1]]]
        x_test += [tmp]

    models = ['lasso','linear','ridge']
    print 'length of y:'+str(np.shape(y_test))+';length of x:'+str(np.shape(x_test))+';length of detX1:'+str(np.shape(detX1))
    for model in models:
        y_pred = showRegression(x_train,y_train,x_test,y_test,comb_list,model)
        title = 'DT-'+model+' results; noise sigma:'+str(noise_sigma)
        plotHist(y_pred,y_test,title)
        if y_value=='residual':
            plotDistribution(y_pred,y_test,x_test,'DT-'+model+' vs GT',manifold=manifold,detX=detX1,y_value='absolute')
        plotDistribution(y_pred,y_test,x_test,'DT-'+model+' vs GT',manifold=manifold,detX=detX1,y_value=y_value)


# This function runs random forest + lasso + ols
def getMLresultsRFLassoOls(sampleX,sampleY,XFsize=3,Psize=5,manifold='Isomap',detX=None,y_value='absolute', noise_sigma=None):

    trainX, testX, trainY, testY = train_test_split(sampleX, sampleY, test_size=0.5, random_state=72)
    # if detX.any() and manifold=='determined':
    #     _, detX1 = train_test_split(np.transpose(detX), test_size=0.5,random_state=72)
    #     detX1 = np.transpose(detX1)
    # else:
    #     detX1 = detX
    clf = RandomForestRegressor()
    clf.fit(trainX,trainY)
    ## the importance of feature x[0] to x[10], an array of 11 elements
    imprt = clf.feature_importances_
    simprt = sorted(clf.feature_importances_,reverse=True)
    tmp = simprt[XFsize]
    XFidx = []
    for i in range(len(imprt)):
        if imprt[i] > tmp:
            XFidx += [i]
            ## XFidx stores the index of top XFsize features
    #print 'index in XF set: '+str(XFidx)
    print 'idx of features selected by Random Forest: '+ str(XFidx)
    comb = list(itertools.combinations_with_replacement(XFidx,2))
    overallidx = XFidx+comb  ## the list of indx of degree one and degree two features, the list has int and tuples
    ## get XFset as all degree one term and degree two terms from XFidx set
    XFset = []
    for i in range(len(trainX)):
        tmp = []
        ## select all degree one term in XFidx
        for j in XFidx:
            tmp += [trainX[i][j]]
        ## add all the degree two term of features with respect to XFidx
        for c in comb:
            tmp += [trainX[i][c[0]]*trainX[i][c[1]]]
        XFset += [tmp]
    ## run lasso, ridge, linear to XFset respectively
    for m in ['lasso']:
        ## largest_coef stores a list of selcted features idx of lasso
        largest_coef = computeFeatureSelection(XFset,trainY,top=Psize,model=m)
        print 'top '+str(Psize)+' largest absolute coef in model '+m+':'
        items = []  ## list of idx
        for i in range(len(largest_coef)):
            items += [overallidx[largest_coef[i]]]
            # print 'the '+str(overallidx[largest_coef[i]])+'-th variable in trainX\n'
        ## items stores the features selected by lasso (is it the list A of significant associations?)
        print(items)
        # ## get true positive portions in items
        # trueFeatures = [0, 1, 2, (0,2), (1,2), (0,5)]
        # numTrue = 0
        # for feature in items:
        #     if feature in trueFeatures:
        #         numTrue = numTrue + 1
        # truePositive = numTrue / len(items)
        # print('the true positive portion:', truePositive)

        ## select corresponding features data from original X train and X test
        pX = genNewX(trainX,items)
        tX = genNewX(testX,items)
        ## fit selcted features train data to ols
        model = sm.OLS(trainY,pX)
        results = model.fit()
        # print(results.summary())
        ## select features after ols based on pvalue
        p_val = results.pvalues
        sigtermIdx = []
        for i, pvalue in enumerate(p_val):
            if pvalue < 0.01:
                sigtermIdx.append(i)
        # print("index after ols:", sigtermIdx)
        olsFeature = np.array(items)[sigtermIdx]
        print "features selected after Ols based on pvalue:" + str(olsFeature)
        # # print("p values are:", p_val)
        # # print(results.summary())
        # parameters = results.params
        # # compute prediction Y for test X
        # resY = []
        # for line in tX:
        #     resY += [np.dot(parameters,line)]
        # # compute test error
        # from sklearn.metrics import mean_squared_error
        # mse = mean_squared_error(testY, resY)
        # print m+' MSE:'+str(mse)+'\n'
        # pscr = pearsonr(testY, resY)
        # print m+' Pearson Corr:'+str(pscr)+'\n'
        # title = 'RandomForest-'+m+' results; noise sigma:'+str(noise_sigma)
        # plotHist(resY,testY,title)
        # title = m+'-RandomForest results; noise sigma:'+str(noise_sigma)
        # if y_value == 'residual':
        #     plotDistribution(resY,testY,tX,title,manifold=manifold,detX=detX1,y_value='absolute')
        # plotDistribution(resY,testY,tX,title,manifold=manifold,detX=detX1,y_value=y_value)
    ## olsFeature is an array storing features selected after ols
    return olsFeature


# This function runs random forest + lasso + OLS on k subsamples to get True Positive rate and false positive rate
def getSubsampleResults(sampleX, sampleY, fold=5):
    kf = KFold(n_splits=fold)
    for i, dataidx in enumerate(kf.split(sampleX)):
        print("results for %d-th subsample"% i)
        subXidx = dataidx[1]
        subX = np.array(sampleX)[subXidx]
        subY = np.array(sampleY)[subXidx]
        axis = determineAxis(subX, manifold='Isomap')
        if i < 1:
            tmpArray = getMLresultsRFLassoOls(subX,subY,XFsize=5,Psize=7,manifold='determined',detX=axis,y_value='residual')
        else:
            newArray = getMLresultsRFLassoOls(subX,subY,XFsize=5,Psize=7,manifold='determined',detX=axis,y_value='residual')
            tmpIntersect = np.intersect1d(tmpArray, newArray)
            tmpArray = tmpIntersect
    commonFeatures = tmpArray
    print '\n' + 'common parts in all the selected features of subsamples:' + str(commonFeatures)
    ### A is the number of common features
    A = len(commonFeatures)
    trueFeatures = [0, 1, 2, (0, 2), (1, 2), (0, 5)]
    numTotalFeatures = 20
    numTrue = 0
    for feature in commonFeatures:
        if feature in trueFeatures:
            numTrue = numTrue + 1
    ### true positive rate is calculated as the common features which are true divided by the number of true features
    truePositive = numTrue / len(trueFeatures)
    print '\n' + "the true positive portion:", str(truePositive), '\n'
    numFalsePositive = 0
    for feature in commonFeatures:
        if feature not in trueFeatures:
            numFalsePositive = numFalsePositive + 1
    falsePositive = numFalsePositive / (numTotalFeatures - len(trueFeatures))
    print 'the number of false positive:' + str(numFalsePositive) + '\n'
    print 'the false positive portion:' + str(falsePositive) + '\n'
    return [truePositive, falsePositive]


# This is the function to do linear regression on original DGP and four additional DGP
def linearReg(x_size = 11,genCore='normal',func = '1', noise_sigma = 1,correlated=True):
    sampleX, sampleY, gt_coef = genData(x_size=x_size, genCore=genCore, func=func, noise_sigma=noise_sigma,
                                        correlated=correlated)
    if func == 'variation2':
        for row in sampleX:
            del row[-1]
    model = sm.OLS(sampleY, sampleX)
    results = model.fit()
    print 'Results for ' + str(func) + '\n'
    print(results.summary())


# This is the function to run Lasso on non-overlapping subsamples and bootstrap subsmaples
def lassoSubsample(sampleX, sampleY, sample_num=10, alpha=0.001,xticks=[],yticks=[], method="kfold",n_samples=800):
    print('alpha ', alpha)
    if method == 'kfold':
        kf = KFold(n_splits=sample_num)
        print(len(sampleX[0]))
        coef = np.zeros((sample_num,len(sampleX[0])))
        for i, dataidx in enumerate(kf.split(sampleX)):
            print("results for %d-th subsample" % i)
            subXidx = dataidx[1]
            subX = np.array(sampleX)[subXidx]
            subY = np.array(sampleY)[subXidx]
            coef[i] = getLassoCoef(subX, subY, alpha=alpha)
            xticklabel = 'subsample'
    elif method == 'bootstrap':
        coef = np.zeros((sample_num,len(sampleX[0])))
        for i in range(10):
            print("results for %d-th bootstrap subsample" % i)
            subX, subY = resample(np.array(sampleX),np.array(sampleY),n_samples=n_samples,random_state=None)
            coef[i] = getLassoCoef(subX, subY, alpha=alpha)
            xticklabel = 'bootstrap sample'
    print(coef)
    plotHeatmap(coef.transpose(),xticks=xticks,yticks=yticks, xticklabel=xticklabel)


# this function runs random forest and then lasso on k fold subsamples or bootstrap
def rfLassoSubsample(sampleX,sampleY,XFsize=3,Psize=5,alpha=0.001,method='kfold'):
    trainX, testX, trainY, testY = train_test_split(sampleX, sampleY, test_size=0.5, random_state=72)
    features = np.array(['Weakness of IP protection (X1)', 'Advertising intensity (X2)', 'R and D intensity (X3)',
                'SGA expenses (X4)', 'Employee satisfaction (X5)', 'Litigation intensity (X6)',
                'Employee diversity (X7)', 'Proportion of TMT with science degrees (X8)', 'Size (employees) (X9)',
                'Age of company (X10)', 'CEO appeared in WSJ (X11)', 'X12'])
    clf = RandomForestRegressor()
    clf.fit(trainX,trainY)
    pred = clf.predict(testX)
    MSE = mean_squared_error(testY, pred)
    print 'MSE for random forest: ' + str(MSE) + '\n'
    # The importance of feature x[0] to x[10], an array of 11 elements
    imprt = clf.feature_importances_

    # Plot relative feature importance
    # make importances relative to max importance
    plotRelFeatureImportance(imprt, features, model='Random Forest')

    # Plot feature importance
    plotFeatureImportance(testX, imprt, model='random forest')

    simprt = sorted(clf.feature_importances_,reverse=True)
    tmp = simprt[XFsize]
    XFidx = []
    for i in range(len(imprt)):
        if imprt[i] > tmp:
            XFidx += [i]
            # XFidx stores the index of top XFsize features
    print 'idx of features selected by Random Forest: '+ str(XFidx)
    comb = list(itertools.combinations_with_replacement(XFidx,2))
    overallidx = XFidx+comb  ## the list of indx of degree one and degree two features, the list has int and tuples
    ## get XFset as all degree one term and degree two terms from XFidx set
    print(overallidx)
    XFset = []
    for i in range(len(trainX)):
        tmp = []
        ## select all degree one term in XFidx
        for j in XFidx:
            tmp += [trainX[i][j]]
        ## add all the degree two term of features with respect to XFidx
        for c in comb:
            tmp += [trainX[i][c[0]]*trainX[i][c[1]]]
        XFset += [tmp]
    yticksLabel = []
    for idx in overallidx:
        if isinstance(idx, int):
            tick = idx + 1
            yticksLabel.append('X%d'%tick)
        else:
            tick1 = idx[0] + 1
            tick2 = idx[1] + 1
            yticksLabel.append('X%dX%d'%(tick1,tick2))
    print(yticksLabel)
    alpha = paramsLasso(XFset, trainY)
    lassoSubsample(XFset, trainY,sample_num=10, alpha=alpha,yticks=yticksLabel,method=method)


# this function runs Neural network then lasso on k subsamples
def NNLassoSubsample(sampleX,sampleY,XFsize=3,Psize=5,alpha=0.001,method='kfold'):
    trainX, testX, trainY, testY = train_test_split(sampleX, sampleY, test_size=0.5, random_state=72)
    features = np.array(['Weakness of IP protection (X1)', 'Advertising intensity (X2)', 'R and D intensity (X3)',
                'SGA expenses (X4)', 'Employee satisfaction (X5)', 'Litigation intensity (X6)',
                'Employee diversity (X7)', 'Proportion of TMT with science degrees (X8)', 'Size (employees) (X9)',
                'Age of company (X10)', 'CEO appeared in WSJ (X11)', 'X12'])
    # Build neural network architecture
    inp = Input(shape=(np.array(trainX).shape[1],))
    x = Dense(128, activation='relu')(inp)
    x = Dense(32, activation='relu')(x)
    out = Dense(1)(x)
    model = Model(inp, out)
    model.compile(optimizer='adam', loss='mse')
    # Fit neural network on training data
    model.fit(np.array(trainX), np.array(trainY), epochs=100, batch_size=128)
    # Predict error on test data
    unscaledPred = model.predict(np.array(testX))
    MAE = mean_absolute_error(testY, unscaledPred)
    print 'MAE for neural network with original data: ' + str(MAE) + '\n'
    # Compute permutation and scoring for each feature
    np.random.seed(33)
    final_score = []
    for i in range(np.array(testX).shape[1]):
        shuff_test = np.array(testX)
        shuff_test[:, i] = np.random.permutation(shuff_test[:, i])
        shuff_unscaledPred = model.predict(shuff_test)
        score = mean_absolute_error(shuff_unscaledPred, testY)
        final_score.append(score)
    final_score = np.array(final_score)
    print 'The final score: ' + str(final_score)
    # Plot feature importance
    plt.bar(range(np.array(testX).shape[1]), (final_score - MAE) / MAE * 100)
    plt.xlabel('Features')
    plt.title('Feature importance of permutation based neural network')
    plt.show()

    imprt = final_score

    # Plot relative feature importance
    # make importances relative to max importance
    plotRelFeatureImportance(imprt, features, model='Neural Network')

    simprt = sorted(final_score, reverse=True)
    tmp = simprt[XFsize]
    XFidx = []
    for i in range(len(imprt)):
        if imprt[i] > tmp:
            XFidx += [i]
            # XFidx stores the index of top XFsize features
    print 'idx of features selected by neural network: ' + str(XFidx)
    comb = list(itertools.combinations_with_replacement(XFidx,2))
    overallidx = XFidx+comb  ## the list of indx of degree one and degree two features, the list has int and tuples
    ## get XFset as all degree one term and degree two terms from XFidx set
    print(overallidx)
    XFset = []
    for i in range(len(trainX)):
        tmp = []
        ## select all degree one term in XFidx
        for j in XFidx:
            tmp += [trainX[i][j]]
        ## add all the degree two term of features with respect to XFidx
        for c in comb:
            tmp += [trainX[i][c[0]]*trainX[i][c[1]]]
        XFset += [tmp]
    yticksLabel = []
    for idx in overallidx:
        if isinstance(idx, int):
            tick = idx + 1
            yticksLabel.append('X%d'%tick)
        else:
            tick1 = idx[0] + 1
            tick2 = idx[1] + 1
            yticksLabel.append('X%dX%d'%(tick1,tick2))
    print(yticksLabel)
    alpha = paramsLasso(XFset, trainY)
    lassoSubsample(XFset, trainY,sample_num=10, alpha=alpha,yticks=yticksLabel,method=method)
    # lassoSubsample(XFset, trainY,fold=10, alpha=alpha,yticks=yticksLabel,method=method)

def GBLassoSubsample(sampleX,sampleY,XFsize=3,Psize=5,alpha=0.001,method='kfold'):
    trainX, testX, trainY, testY = train_test_split(sampleX, sampleY, test_size=0.5, random_state=72)
    features = np.array(['Weakness of IP protection (X1)', 'Advertising intensity (X2)', 'R and D intensity (X3)',
                'SGA expenses (X4)', 'Employee satisfaction (X5)', 'Litigation intensity (X6)',
                'Employee diversity (X7)', 'Proportion of TMT with science degrees (X8)', 'Size (employees) (X9)',
                'Age of company (X10)', 'CEO appeared in WSJ (X11)', 'X12'])
    params = {'n_estimators': 100, 'learning_rate': 0.1, 'max_depth': 1, 'random_state': 0, 'loss': 'ls'}
    clf = GradientBoostingRegressor(**params)
    clf.fit(trainX, trainY)
    pred = clf.predict(testX)
    MSE = mean_squared_error(testY, pred)
    print 'MSE for gradient descent: ' + str(MSE) + '\n'
    # The importance of feature x[0] to x[10], an array of 11 elements
    imprt = clf.feature_importances_

    # Plot prediction intervals for Gradient Boosting Regression
    plotPredIntervalGBDT(trainX, trainY, testX, testY, pred)

    # Plot training deviance
    # compute test set deviance
    plotDevianceGBDT(params, clf, testX, testY)

    # Plot relative feature importance
    # make importances relative to max importance
    plotRelFeatureImportance(imprt, features, model='Gradient Boosting')

    # Plot feature importance
    plotFeatureImportance(testX, imprt, model='gradient boosting')

    simprt = sorted(clf.feature_importances_, reverse=True)
    tmp = simprt[XFsize]
    XFidx = []
    for i in range(len(imprt)):
        if imprt[i] > tmp:
            XFidx += [i]
            # XFidx stores the index of top XFsize features
    print 'idx of features selected by Gradient Boosting: ' + str(XFidx)
    comb = list(itertools.combinations_with_replacement(XFidx,2))
    overallidx = XFidx+comb  ## the list of indx of degree one and degree two features, the list has int and tuples
    ## get XFset as all degree one term and degree two terms from XFidx set
    print(overallidx)
    XFset = []
    for i in range(len(trainX)):
        tmp = []
        ## select all degree one term in XFidx
        for j in XFidx:
            tmp += [trainX[i][j]]
        ## add all the degree two term of features with respect to XFidx
        for c in comb:
            tmp += [trainX[i][c[0]]*trainX[i][c[1]]]
        XFset += [tmp]
    yticksLabel = []
    for idx in overallidx:
        if isinstance(idx, int):
            tick = idx + 1
            yticksLabel.append('X%d'%tick)
        else:
            tick1 = idx[0] + 1
            tick2 = idx[1] + 1
            yticksLabel.append('X%dX%d'%(tick1,tick2))
    print(yticksLabel)
    alpha = paramsLasso(XFset, trainY)
    lassoSubsample(XFset, trainY,sample_num=10, alpha=alpha,yticks=yticksLabel,method=method)
    # lassoSubsample(XFset, trainY,fold=10, alpha=alpha,yticks=yticksLabel,method=method)

# this function creats a vector of length 77 such that it covers all the linear and non linear combinations of the 11 variables.
# the vector zero if an element is non-significant and 1 else.
def OLSDegree2ResultsVector(sampleX, sampleY,XFidx,Pvalue=0.01):
    print 'OLSModel for all degree 2 variables:\n'
    x = genLongX(sampleX)
    model = sm.OLS(sampleY,x)
    results = model.fit()
    p_val = results.pvalues
    print results.summary()
    resVector = []
    for pvalue in p_val:
        if pvalue < Pvalue :
            resVector.append(1)
        else:
            resVector.append(0)
    print resVector
    idx = [i for i, x in enumerate(resVector) if x == 1]
    print(np.array(XFidx)[idx])
    return resVector


# This function ran RF + RF
def getRfRfresultsNewX(sampleX,sampleY,XFsize=3,Psize=5,Pvalue=0.01):

    trainX, testX, trainY, testY = train_test_split(sampleX, sampleY, test_size=0.5, random_state=72)
    features = np.array(['Weakness of IP protection (X1)', 'Advertising intensity (X2)', 'R and D intensity (X3)',
                'SGA expenses (X4)', 'Employee satisfaction (X5)', 'Litigation intensity (X6)',
                'Employee diversity (X7)', 'Proportion of TMT with science degrees (X8)', 'Size (employees) (X9)',
                'Age of company (X10)', 'CEO appeared in WSJ (X11)', 'X12'])
    clf = RandomForestRegressor()
    clf.fit(trainX,trainY)
    pred = clf.predict(testX)
    MSE = mean_squared_error(testY, pred)
    print 'MSE for random forest: ' + str(MSE) + '\n'
    # The importance of feature x[0] to x[10], an array of 11 elements
    imprt = clf.feature_importances_

    # Plot relative feature importance
    # make importances relative to max importance
    plotRelFeatureImportance(imprt, features, model='Random Forest')

    # Plot feature importance
    plotFeatureImportance(testX, imprt, model='random forest')

    simprt = sorted(clf.feature_importances_,reverse=True)
    tmp = simprt[XFsize]
    XFidx = []
    for i in range(len(imprt)):
        if imprt[i] > tmp:
            XFidx += [i]
            # XFidx stores the index of top XFsize features
    print 'idx of features selected by Random Forest: '+ str(XFidx)
    comb = list(itertools.combinations_with_replacement(XFidx,2))
    overallidx = XFidx+comb  ## the list of indx of degree one and degree two features, the list has int and tuples
    ## get XFset as all degree one term and degree two terms from XFidx set
    XFset = []
    for i in range(len(trainX)):
        tmp = []
        ## select all degree one term in XFidx
        for j in XFidx:
            tmp += [trainX[i][j]]
        ## add all the degree two term of features with respect to XFidx
        for c in comb:
            tmp += [trainX[i][c[0]]*trainX[i][c[1]]]
        XFset += [tmp]
    ## run lasso, ridge, linear to XFset respectively
    for m in ['RandomForest']:
        ## largest_coef stores a list of selcted features idx of given model
        largest_coef = computeFeatureSelectionNewLasso(XFset,trainY,top=Psize,model=m)
        print 'top '+str(Psize)+' largest absolute coef in model '+m+':\n'
        items = []  ## list of idx
        for i in range(len(largest_coef)):
            items += [overallidx[largest_coef[i]]]
            print 'the '+str(overallidx[largest_coef[i]])+'-th variable in trainX\n'
        ## select corresponding features data from original X train and X test
        pX = genNewXmodified(trainX,items)[0]
        tX = genNewXmodified(testX,items)[0]
        ## fit selcted features train data to ols
        model = sm.OLS(trainY,pX)
        results = model.fit()
        # p_val = results.pvalues
        print(results.summary())
        print '\n' + 'residual MSE: ' + str(results.mse_resid)
        parameters = results.params
        ## select features after ols based on pvalue
        firstOlsTerm = genNewXmodified(trainX,items)[1]
        p_val = results.pvalues
        sigtermIdx = []
        for i, pvalue in enumerate(p_val):
            if pvalue < 0.01:
                sigtermIdx.append(i)
        # print("index after ols:", sigtermIdx)
        olsFeature = np.array(firstOlsTerm)[sigtermIdx]
        print "features selected after Ols Model(1) based on pvalue:" + str(olsFeature)
        # Run second ols after drop insignificant terms
        secondOlsX = genNewXmodified(trainX, olsFeature)[0]
        results2 = sm.OLS(trainY, secondOlsX).fit()
        print(results2.summary())
        print '\n' + 'residual MSE: ' + str(results2.mse_resid)
        print '\n'
        # Fit model(2) to test data
        print "OLS Results for deductive sample: " + '\n'
        deductiveX = genNewXmodified(testX,olsFeature)[0]
        decOlsTerms = genNewXmodified(testX,olsFeature)[1]
        results3 = sm.OLS(testY, deductiveX).fit()
        print(results3.summary())
        print '\n' + 'residual MSE: ' + str(results3.mse_resid)
        p_val2 = results3.pvalues
        sigtermIdx2 = []
        for i, pvalue in enumerate(p_val2):
            if pvalue < Pvalue:
                sigtermIdx2.append(i)
        # print("index after ols:", sigtermIdx)
        olsFeature2 = np.array(decOlsTerms)[sigtermIdx2]
        print "features selected after Ols Model on deductive sample based on pvalue:" + str(olsFeature2)
        return olsFeature2

# This function ran Lasso + RF
def getLassoRfResultsNewX(sampleX,sampleY,XFsize=3,Psize=5,Pvalue=0.01):

    trainX, testX, trainY, testY = train_test_split(sampleX, sampleY, test_size=0.5, random_state=72)
    features = np.array(['Weakness of IP protection (X1)', 'Advertising intensity (X2)', 'R and D intensity (X3)',
                'SGA expenses (X4)', 'Employee satisfaction (X5)', 'Litigation intensity (X6)',
                'Employee diversity (X7)', 'Proportion of TMT with science degrees (X8)', 'Size (employees) (X9)',
                'Age of company (X10)', 'CEO appeared in WSJ (X11)', 'X12'])
    clf = linear_model.LassoCV(cv=5,random_state=0)
    clf.fit(trainX,trainY)
    print 'CV alpha for Lasso is: '+str(clf.alpha_)+'\n'
    pred = clf.predict(testX)
    MSE = mean_squared_error(testY, pred)
    print 'MSE for Lasso: ' + str(MSE) + '\n'
    # The importance of feature x[0] to x[10], an array of 11 elements
    coefLasso = clf.coef_
    imprt = np.array(map(abs, coefLasso))

    # Plot relative feature importance
    # make importances relative to max importance
    plotRelFeatureImportance(imprt, features, model='Random Forest')

    # Plot feature importance
    plotFeatureImportance(testX, imprt, model='random forest')

    simprt = sorted(imprt,reverse=True)
    tmp = simprt[XFsize]
    XFidx = []
    for i in range(len(imprt)):
        if imprt[i] > tmp:
            XFidx += [i]
            # XFidx stores the index of top XFsize features
    print 'idx of features selected by Lasso: '+ str(XFidx)
    comb = list(itertools.combinations_with_replacement(XFidx,2))
    overallidx = XFidx+comb  ## the list of indx of degree one and degree two features, the list has int and tuples
    ## get XFset as all degree one term and degree two terms from XFidx set
    XFset = []
    for i in range(len(trainX)):
        tmp = []
        ## select all degree one term in XFidx
        for j in XFidx:
            tmp += [trainX[i][j]]
        ## add all the degree two term of features with respect to XFidx
        for c in comb:
            tmp += [trainX[i][c[0]]*trainX[i][c[1]]]
        XFset += [tmp]
    ## run lasso, ridge, linear to XFset respectively
    for m in ['RandomForest']:
        ## largest_coef stores a list of selcted features idx of given model
        largest_coef = computeFeatureSelectionNewLasso(XFset,trainY,top=Psize,model=m)
        print 'top '+str(Psize)+' largest absolute coef in model '+m+':\n'
        items = []  ## list of idx
        for i in range(len(largest_coef)):
            items += [overallidx[largest_coef[i]]]
            print 'the '+str(overallidx[largest_coef[i]])+'-th variable in trainX\n'
        ## select corresponding features data from original X train and X test
        pX = genNewXmodified(trainX,items)[0]
        tX = genNewXmodified(testX,items)[0]
        ## fit selcted features train data to ols
        model = sm.OLS(trainY,pX)
        results = model.fit()
        # p_val = results.pvalues
        print(results.summary())
        print '\n' + 'residual MSE: ' + str(results.mse_resid)
        parameters = results.params
        ## select features after ols based on pvalue
        firstOlsTerm = genNewXmodified(trainX,items)[1]
        p_val = results.pvalues
        sigtermIdx = []
        for i, pvalue in enumerate(p_val):
            if pvalue < 0.01:
                sigtermIdx.append(i)
        # print("index after ols:", sigtermIdx)
        olsFeature = np.array(firstOlsTerm)[sigtermIdx]
        print "features selected after Ols Model(1) based on pvalue:" + str(olsFeature)
        # Run second ols after drop insignificant terms
        secondOlsX = genNewXmodified(trainX, olsFeature)[0]
        results2 = sm.OLS(trainY, secondOlsX).fit()
        print(results2.summary())
        print '\n' + 'residual MSE: ' + str(results2.mse_resid)
        print '\n'
        # Fit model(2) to test data
        print "OLS Results for deductive sample: " + '\n'
        deductiveX = genNewXmodified(testX,olsFeature)[0]
        decOlsTerms = genNewXmodified(testX,olsFeature)[1]
        results3 = sm.OLS(testY, deductiveX).fit()
        print(results3.summary())
        print '\n' + 'residual MSE: ' + str(results3.mse_resid)
        p_val2 = results3.pvalues
        sigtermIdx2 = []
        for i, pvalue in enumerate(p_val2):
            if pvalue < Pvalue:
                sigtermIdx2.append(i)
        # print("index after ols:", sigtermIdx)
        olsFeature2 = np.array(decOlsTerms)[sigtermIdx2]
        print "features selected after Ols Model on deductive sample based on pvalue:" + str(olsFeature2)
        return olsFeature2


# This function ran Lasso + Lasso
def getLassoLassoResultsNewX(sampleX,sampleY,XFsize=3,Psize=5,Pvalue=0.01):

    trainX, testX, trainY, testY = train_test_split(sampleX, sampleY, test_size=0.5, random_state=72)
    features = np.array(['Weakness of IP protection (X1)', 'Advertising intensity (X2)', 'R and D intensity (X3)',
                'SGA expenses (X4)', 'Employee satisfaction (X5)', 'Litigation intensity (X6)',
                'Employee diversity (X7)', 'Proportion of TMT with science degrees (X8)', 'Size (employees) (X9)',
                'Age of company (X10)', 'CEO appeared in WSJ (X11)', 'X12'])
    clf = linear_model.LassoCV(cv=5,random_state=0)
    clf.fit(trainX,trainY)
    print 'CV alpha for Lasso is: '+str(clf.alpha_)+'\n'
    pred = clf.predict(testX)
    MSE = mean_squared_error(testY, pred)
    print 'MSE for Lasso: ' + str(MSE) + '\n'
    # The importance of feature x[0] to x[10], an array of 11 elements
    coefLasso = clf.coef_
    imprt = np.array(map(abs, coefLasso))

    # Plot relative feature importance
    # make importances relative to max importance
    plotRelFeatureImportance(imprt, features, model='Random Forest')

    # Plot feature importance
    plotFeatureImportance(testX, imprt, model='random forest')

    simprt = sorted(imprt,reverse=True)
    tmp = simprt[XFsize]
    XFidx = []
    for i in range(len(imprt)):
        if imprt[i] > tmp:
            XFidx += [i]
            # XFidx stores the index of top XFsize features
    print 'idx of features selected by Lasso: '+ str(XFidx)
    comb = list(itertools.combinations_with_replacement(XFidx,2))
    overallidx = XFidx+comb  ## the list of indx of degree one and degree two features, the list has int and tuples
    ## get XFset as all degree one term and degree two terms from XFidx set
    XFset = []
    for i in range(len(trainX)):
        tmp = []
        ## select all degree one term in XFidx
        for j in XFidx:
            tmp += [trainX[i][j]]
        ## add all the degree two term of features with respect to XFidx
        for c in comb:
            tmp += [trainX[i][c[0]]*trainX[i][c[1]]]
        XFset += [tmp]
    ## run lasso, ridge, linear to XFset respectively
    for m in ['lasso']:
        ## largest_coef stores a list of selcted features idx of given model
        largest_coef = computeFeatureSelectionNewLasso(XFset,trainY,top=Psize,model=m)
        print 'top '+str(Psize)+' largest absolute coef in model '+m+':\n'
        items = []  ## list of idx
        for i in range(len(largest_coef)):
            items += [overallidx[largest_coef[i]]]
            print 'the '+str(overallidx[largest_coef[i]])+'-th variable in trainX\n'
        ## select corresponding features data from original X train and X test
        pX = genNewXmodified(trainX,items)[0]
        tX = genNewXmodified(testX,items)[0]
        ## fit selcted features train data to ols
        model = sm.OLS(trainY,pX)
        results = model.fit()
        # p_val = results.pvalues
        print(results.summary())
        print '\n' + 'residual MSE: ' + str(results.mse_resid)
        parameters = results.params
        ## select features after ols based on pvalue
        firstOlsTerm = genNewXmodified(trainX,items)[1]
        p_val = results.pvalues
        sigtermIdx = []
        for i, pvalue in enumerate(p_val):
            if pvalue < 0.01:
                sigtermIdx.append(i)
        # print("index after ols:", sigtermIdx)
        olsFeature = np.array(firstOlsTerm)[sigtermIdx]
        print "features selected after Ols Model(1) based on pvalue:" + str(olsFeature)
        # Run second ols after drop insignificant terms
        secondOlsX = genNewXmodified(trainX, olsFeature)[0]
        results2 = sm.OLS(trainY, secondOlsX).fit()
        print(results2.summary())
        print '\n' + 'residual MSE: ' + str(results2.mse_resid)
        print '\n'
        # Fit model(2) to test data
        print "OLS Results for deductive sample: " + '\n'
        deductiveX = genNewXmodified(testX,olsFeature)[0]
        decOlsTerms = genNewXmodified(testX,olsFeature)[1]
        results3 = sm.OLS(testY, deductiveX).fit()
        print(results3.summary())
        print '\n' + 'residual MSE: ' + str(results3.mse_resid)
        p_val2 = results3.pvalues
        sigtermIdx2 = []
        for i, pvalue in enumerate(p_val2):
            if pvalue < Pvalue:
                sigtermIdx2.append(i)
        # print("index after ols:", sigtermIdx)
        olsFeature2 = np.array(decOlsTerms)[sigtermIdx2]
        print "features selected after Ols Model on deductive sample based on pvalue:" + str(olsFeature2)
        return olsFeature2






