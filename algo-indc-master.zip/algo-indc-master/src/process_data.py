import numpy as np
import itertools
from sklearn import linear_model
from sklearn.ensemble import RandomForestRegressor
from sklearn.neural_network import MLPRegressor


def genLongX(sampleX):
    res = []
    comb2_list = list(itertools.combinations_with_replacement(range(len(sampleX[0])),2))
    XFidx = []
    for i in range(len(sampleX[0])):
        XFidx.append(i)
    for comb in comb2_list:
        XFidx.append(comb)
    print 'all 77 terms for linear regression are:' + '\n'
    print(XFidx)
    for i in range(len(sampleX)):
        tmp = []
        tmp += sampleX[i]
        for comb in comb2_list:
            tmp += [sampleX[i][comb[0]]*sampleX[i][comb[1]]]
        res += [tmp]
    return res

def getLRCoef(sampleX, sampleY):
    clf = linear_model.LinearRegression()
    clf.fit(sampleX, sampleY)
    return clf.coef_

def getLassoCoef(sampleX, sampleY, alpha=0.001):
    clf = linear_model.Lasso(alpha)
    clf.fit(sampleX, sampleY)
    return clf.coef_

def getRidgeCoef(sampleX, sampleY, alpha=0.1):
    clf = linear_model.Ridge(alpha)
    clf.fit(sampleX, sampleY)
    return clf.coef_

def getRandomForestCoef(sampleX, sampleY):
    clf = RandomForestRegressor()
    clf.fit(sampleX,sampleY)
    return clf.feature_importances_

def getMLPCoef(sampleX, sampleY):
    clf = MLPRegressor(hidden_layer_sizes=(100, 100),
                       tol=1e-2, max_iter=500, random_state=0)
    clf.fit(sampleX, sampleY)
    return clf.coefs_

# This function generates full x index with 77 terms
def xFullidx(sampleX):
    comb2_list = list(itertools.combinations_with_replacement(range(len(sampleX[0])),2))
    XFidx = []
    for i in range(len(sampleX[0])):
        XFidx.append(i)
    for comb in comb2_list:
        XFidx.append(comb)
    print 'all 77 terms for linear regression are:' + '\n'
    print(XFidx)
    return XFidx

