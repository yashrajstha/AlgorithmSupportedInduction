import numpy as np
from sklearn import linear_model
import statsmodels.api as sm
from sklearn.manifold import Isomap, MDS, SpectralEmbedding, LocallyLinearEmbedding
from gen_data import genNewX
from process_data import getLassoCoef, getLRCoef, getRandomForestCoef, getRidgeCoef
import matplotlib.pyplot as plt

def determineAxis(sampleX, manifold):
    if manifold=='Isomap':
        embedding = Isomap(n_components=2)
    if manifold=='MDS':
        embedding = MDS(n_components=2)
    if manifold=='SpectralEmbedding':
        embedding = SpectralEmbedding(n_components=2)
    if manifold=='LocallyLinearEmbedding':
        embedding=LocallyLinearEmbedding(n_components=2)
    X_transformed = embedding.fit_transform(sampleX)
    X_transposed = np.transpose(X_transformed)
    return X_transposed


def genGTCoef(b,func='1'):
    gt_coef = [0 for i in range(65)]
    gt_coef[0],gt_coef[1],gt_coef[2] = b[0],b[1],b[2]
    if func == '1':
        gt_coef[12],gt_coef[21] = b[11],b[12]
    return gt_coef


def computeMSEforTopFeatures(gt_coef,target_coef,top=10):
    tmp = sorted(abs(target_coef),reverse=True)
    top_num = tmp[top]
    target_top = {}
    gt_top = {}
    mse = 0
    for i in range(len(gt_coef)):
        if abs(target_coef[i]) > top_num:
            target_top[i] = target_coef[i]
            gt_top[i] = gt_coef[i]
            mse += (target_coef[i]-gt_coef[i])**2
    return mse, gt_top, target_top

# The function calculates the coeff for giving model, and selects top "top" features by abs of coeff
def computeFeatureSelection(x,sampleY,top=10,model='lasso'):
    if model == 'lasso':
        target_coef = getLassoCoef(x,sampleY)
    elif model == 'linear':
        target_coef = getLRCoef(x, sampleY)
    elif model == 'RandomForest':
        target_coef = getRandomForestCoef(x,sampleY)
    elif model == 'ridge':
        target_coef = getRidgeCoef(x,sampleY,alpha=1)
    #mse, gt_top, target_top = computeMSEforTopFeatures(gt_coef,target_coef,top=10)
    target_coef_abs = np.abs(target_coef)
    # sort abs of coeff from max to min
    s_coef = sorted(target_coef_abs,reverse=True)
    tmp = s_coef[top]
    ## target_top stores the idx of top "top" high abs coeff features idx
    target_top = []
    for i in range(len(target_coef)):
        if abs(target_coef[i]) > tmp:
            target_top += [i]
    print model+':\n'
    print 'idx of coefficient with largest absolute value: '+str(target_top)
    return target_top
    ## return selected features' idx


def printDT(estimator):
    # Using those arrays, we can parse the tree structure:
    n_nodes = estimator.tree_.node_count
    children_left = estimator.tree_.children_left
    children_right = estimator.tree_.children_right
    feature = estimator.tree_.feature
    threshold = estimator.tree_.threshold

    # The tree structure can be traversed to compute various properties such
    # as the depth of each node and whether or not it is a leaf.
    node_depth = np.zeros(shape=n_nodes, dtype=np.int64)
    is_leaves = np.zeros(shape=n_nodes, dtype=bool)
    stack = [(0, -1)]  # seed is the root node id and its parent depth
    while len(stack) > 0:
        node_id, parent_depth = stack.pop()
        node_depth[node_id] = parent_depth + 1

        # If we have a test node
        if (children_left[node_id] != children_right[node_id]):
            stack.append((children_left[node_id], parent_depth + 1))
            stack.append((children_right[node_id], parent_depth + 1))
        else:
            is_leaves[node_id] = True

    print("The binary tree structure has %s nodes and has "
          "the following tree structure:"
          % n_nodes)

    #find the three nodes closest to the root
    cur_layer = [0]
    branches = set()
    while not is_leaves[cur_layer[0]]:
        next_layer = []
        for j in cur_layer:
            next_layer += [children_left[j],children_right[j]]
            if len(branches) < 4:
                branches.add(feature[j])
        cur_layer = next_layer
    for i in range(n_nodes):
        if is_leaves[i]:
            print("%snode=%s leaf node." % (node_depth[i] * "\t", i))
        else:
            print("%snode=%s test node: go to node %s if X[:, %s] <= %s else to "
                  "node %s."
                  % (node_depth[i] * "\t",
                     i,
                     children_left[i],
                     feature[i],
                     threshold[i],
                     children_right[i],
                     ))
    return branches


def showRegression(x_train,y_train,x_test,y_test,comb_list,m='lasso',Psize=7):
    from scipy.stats import pearsonr
    from sklearn.metrics import mean_squared_error
    factor_name = range(11)+comb_list
    if m == 'lasso':
        clf = linear_model.Lasso(alpha=0.001)
    elif m == 'linear':
        clf = linear_model.LinearRegression()
    elif m == 'ridge':
        clf = linear_model.Ridge(alpha=0.1)
    clf.fit(x_train, y_train)
    y_pred = clf.predict(x_test)
    coef = clf.coef_
    print 'Top '+str(Psize)+' Xs after linear model:\n'
    tmpsort = sorted(map(abs,coef),reverse=True)
    thres = tmpsort[Psize]
    items = []
    for i in range(len(coef)):
        if abs(coef[i]) > thres:
            print 'X'+str(factor_name[i])+':'+str(coef[i])
            items += [factor_name[i]]
    pX = genNewX(x_train,items)
    tX = genNewX(x_test,items)
    model = sm.OLS(y_train,pX)
    results = model.fit()
    p_val = results.pvalues
    print(results.summary())
    parameters = results.params
    resY = []
    for line in tX:
        resY += [np.dot(parameters,line)]
    mse = mean_squared_error(y_test, resY)
    print m+' MSE:'+str(mse)+'\n'
    pscr = pearsonr(y_test, resY)
    print m+' Pearson Corr:'+str(pscr)+'\n'
    return resY


# This function shows different alpha value for LASSO
def computeFeatureSelectionNewLasso(x,sampleY,top=10,model='lasso'):
    ## the function calculates the coeff for giving model, and selects top "top" features by abs of coeff
    if model == 'lasso':
        alpha=paramsLasso(x, sampleY)
        target_coef = getLassoCoef(x,sampleY,alpha=alpha)
    elif model == 'linear':
        target_coef = getLRCoef(x, sampleY)
    elif model == 'RandomForest':
        target_coef = getRandomForestCoef(x,sampleY)
    elif model == 'ridge':
        target_coef = getRidgeCoef(x,sampleY,alpha=1)
    #mse, gt_top, target_top = computeMSEforTopFeatures(gt_coef,target_coef,top=10)
    target_coef_abs = np.abs(target_coef)
    # sort abs of coeff from max to min
    s_coef = sorted(target_coef_abs,reverse=True)
    tmp = s_coef[top]
    ## target_top stores the idx of top "top" high abs coeff features idx
    target_top = []
    for i in range(len(target_coef)):
        if abs(target_coef[i]) > tmp:
            target_top += [i]
    print model+':\n'
    print 'idx of coefficient with largest absolute value: '+str(target_top)
    return target_top
    ## return selected features' idx


# Lasso alpha value selection based on cross validation, plot different cv mse of different alpha, return best alpha
def paramsLasso(sampleX, sampleY):
    EPSILON = 1e-4
    # Compute paths
    print("Computing regularization path using the coordinate descent lasso...")
    model = linear_model.LassoCV(cv=20).fit(sampleX, sampleY)

    # Display results
    m_log_alphas = -np.log10(model.alphas_ + EPSILON)

    plt.figure()
    # ymin, ymax = 2300, 3800
    plt.plot(m_log_alphas, model.mse_path_, ':')
    plt.plot(m_log_alphas, model.mse_path_.mean(axis=-1), 'k',
             label='Average across the folds', linewidth=2)
    plt.axvline(-np.log10(model.alpha_ + EPSILON), linestyle='--', color='k',
                label='alpha: CV estimate')
    plt.legend()
    plt.xlabel('-log(alpha)')
    plt.ylabel('Mean square error')
    plt.title('Mean square error on each fold')
    plt.axis('tight')
    # plt.ylim(ymin, ymax)
    plt.show()
    print '\n' + 'Alpha chosen for LASSO is:' + str(model.alpha_)
    return model.alpha_

# This function is doing CV on lasso feature selection
def computeCVFeatureSelection(x,sampleY,top=10,model='lasso'):
    ## the function calculates the coeff for giving model, and selects top "top" features by abs of coeff
    if model == 'lasso':

        target_coef = getLassoCoef(x,sampleY)
    elif model == 'linear':
        target_coef = getLRCoef(x, sampleY)
    elif model == 'RandomForest':
        target_coef = getRandomForestCoef(x,sampleY)
    elif model == 'ridge':
        target_coef = getRidgeCoef(x,sampleY,alpha=1)
    #mse, gt_top, target_top = computeMSEforTopFeatures(gt_coef,target_coef,top=10)
    target_coef_abs = np.abs(target_coef)
    # sort abs of coeff from max to min
    s_coef = sorted(target_coef_abs,reverse=True)
    tmp = s_coef[top]
    ## target_top stores the idx of top "top" high abs coeff features idx
    target_top = []
    for i in range(len(target_coef)):
        if abs(target_coef[i]) > tmp:
            target_top += [i]
    print model+':\n'
    print 'idx of coefficient with largest absolute value: '+str(target_top)
    return target_top
    ## return selected features' idx

# This function calculates Hamming distance
def hamming(x, y):
    """
    :param x: list of 1 and 0
    :param y: list of 1 and 0
    :return: integer
    """
    count = 0
    for i in range(len(x)):
        if x[i] != y[i]:
            count += 1
    print 'hamming distance is: ' + str(count)
    return count

