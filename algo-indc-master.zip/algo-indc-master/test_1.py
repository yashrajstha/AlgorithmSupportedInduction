import numpy as np
from numpy.core._multiarray_umath import ndarray
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from plot import plotFeatureImportance
from scipy.stats import pearsonr
# from run_model import getOLSModelDegree1, getOLSModelOneDegree2, getOLSModelTwoDegree2, getOLSModelDegree2, \
#     runStepwiseRegression, getMLresults, runDT, getMLresultsGBDT, getSubsampleResults
from run_model import neuralNetFeatureImportance,getMLresults, runDT, getMLresultsGBDT, getSubsampleResults, \
    getMLresultsRFLassoOls,getMLresultsNewX, getMLresultsGBDTNewX,linearReg,lassoSubsample,rfLassoSubsample,\
    GBLassoSubsample,NNLassoSubsample,OLSDegree2ResultsVector,getRfRfresultsNewX,getLassoRfResultsNewX,\
    getLassoLassoResultsNewX
from gen_data import genData
from process_data import genLongX,xFullidx
from plot import plotHist, plotDistribution
from utils import determineAxis, paramsLasso,hamming
import matplotlib.pyplot as plt
import time

print ('########################## Original DGP: gen X from normal+correlation=-0.3 ##################################')
np.random.seed(42)
noise_sigma = 0.7
sampleX, sampleY, gt_coef = genData(x_size=11,genCore='normal',func= '1',noise_sigma=noise_sigma,correlated=True)

print '################### RF(top 5 features selected)+ LASSO, ridge, linear with extra term in ols ##############' + '\n'
getMLresultsNewX(sampleX,sampleY,XFsize=5,Psize=7)

print '########### Gradient boosting(top 5 features selected) + LASSO, ridge, linear with extra term in ols ##########' + '\n'
getMLresultsGBDTNewX(sampleX,sampleY,XFsize=5,Psize=7)

print '################### NN(top 5 features selected) + LASSO, ridge, linear with extra term in ols ################' + '\n'
neuralNetFeatureImportance(sampleX,sampleY,XFsize=5,Psize=7)





# Original DGP: True positive and False Positive rate of non-overlapping subssamples with different folds k
print '\n'
axis = determineAxis(sampleX,manifold='Isomap')
print "Linear Regresson on 2 second-order items with k non-overlapping subsamples, model in ['lasso','RandomForest','OLS']"
print '###Plot true positive rate for different k###' + '\n'
truerate = []
for k in range(2,11):
    print "When number of folds is: " + str(k) + "\n"
    truerate.append(getSubsampleResults(sampleX,sampleY,fold=k))

print("list of true positive rate for different num of folds:", truerate)

x = range(2,11)
y = truerate

plt.xlabel('number of subsamples: k')
plt.ylabel('True Positive Rate')
plt.plot(x,y)
plt.show()

print '\n'
print '###Plot false positive rate for different k###' + '\n'
falsePositiveRate = []
for k in range(2,11):
    print "When number of folds is: " + str(k) + '\n'
    falsePositiveRate.append(getSubsampleResults(sampleX,sampleY,fold=k)[1])
print "List of false positive rate for different num of folds: " + str(falsePositiveRate)
x = range(2,11)
y = falsePositiveRate
plt.xlabel('number of subsamples: k')
plt.ylabel('False Positive Rate')
plt.plot(x,y)
plt.show()
