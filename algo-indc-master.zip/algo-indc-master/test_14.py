import numpy as np
from numpy.core._multiarray_umath import ndarray
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from plot import plotFeatureImportance
from scipy.stats import pearsonr
# from run_model import getOLSModelDegree1, getOLSModelOneDegree2, getOLSModelTwoDegree2, getOLSModelDegree2, \
#     runStepwiseRegression, getMLresults, runDT, getMLresultsGBDT, getSubsampleResults
from run_model import neuralNetFeatureImportance,getMLresults, runDT, getMLresultsGBDT, getSubsampleResults, \
    getMLresultsRFLassoOls,getMLresultsNewX, getMLresultsGBDTNewX,linearReg,lassoSubsample,rfLassoSubsample,\
    GBLassoSubsample,NNLassoSubsample,OLSDegree2ResultsVector,getRfRfresultsNewX,getLassoRfResultsNewX,\
    getLassoLassoResultsNewX
from gen_data import genData
from process_data import genLongX,xFullidx
from plot import plotHist, plotDistribution
from utils import determineAxis, paramsLasso,hamming
import matplotlib.pyplot as plt
import time

# DGP 4: Hamming distance comparison, p value = 0.01
print "##### DGP 4 ###" + "\n"
print ('########################## gen X from normal+correlation=-0.3 ##################################')
np.random.seed(42)
noise_sigma = 0.7
sampleX, sampleY, gt_coef = genData(x_size=11,genCore='normal',func='variation4',noise_sigma=noise_sigma,correlated=True)

# Generate 77 terms with all degree 2 terms and get ols regression significant term vector
xFIdx = xFullidx(sampleX)
olsVector = OLSDegree2ResultsVector(sampleX,sampleY,XFidx=xFIdx,Pvalue=0.01)
print(len(olsVector))

# Result vector of our algo-induc approach
decOlsTerm = getMLresultsNewX(sampleX,sampleY,XFsize=5,Psize=7,Pvalue=0.01)
print '\n' + str(decOlsTerm)
print(list(decOlsTerm))
decVector = []
for idx in xFIdx:
    if idx in set(list(decOlsTerm)):
        decVector.append(1)
    else:
        decVector.append(0)
print '\n' + 'deductive vector is:' + str(decVector)
print(len(decVector))

# Result vector of degree 1 linear regression
linearVector = [0] * 77
for i in range(3):
    linearVector[i] = 1
print '\n' + 'linear terms vector is ' + str(linearVector)
print(len(linearVector))

# Vector of true DGP
trueVector = [1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
print(len(trueVector))

hamming(olsVector,decVector)
hamming(olsVector, linearVector)
hamming(decVector, linearVector)
hamming(trueVector,olsVector)
hamming(trueVector,decVector)
hamming(trueVector,linearVector)


# p value is 0.05
print ('########################## gen X from normal+correlation=-0.3 ##################################')
np.random.seed(42)
noise_sigma = 0.7
sampleX, sampleY, gt_coef = genData(x_size=11,genCore='normal',func='variation4',noise_sigma=noise_sigma,correlated=True)

# Generate 77 terms with all degree 2 terms and get ols regression significant term vector
xFIdx = xFullidx(sampleX)
olsVector = OLSDegree2ResultsVector(sampleX,sampleY,XFidx=xFIdx,Pvalue=0.05)
print(len(olsVector))

# Result vector of our algo-induc approach
decOlsTerm = getMLresultsNewX(sampleX,sampleY,XFsize=5,Psize=7,Pvalue=0.05)
print '\n' + str(decOlsTerm)
print(list(decOlsTerm))
decVector = []
for idx in xFIdx:
    if idx in set(list(decOlsTerm)):
        decVector.append(1)
    else:
        decVector.append(0)
print '\n' + 'deductive vector is:' + str(decVector)
print(len(decVector))

# Result vector of degree 1 linear regression
linearVector = [0] * 77
for i in range(3):
    linearVector[i] = 1
print '\n' + 'linear terms vector is ' + str(linearVector)
print(len(linearVector))

# Vector of true DGP
trueVector = [1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
print(len(trueVector))

hamming(olsVector,decVector)
hamming(olsVector, linearVector)
hamming(decVector, linearVector)
hamming(trueVector,olsVector)
hamming(trueVector,decVector)
hamming(trueVector,linearVector)