import numpy as np
from numpy.core._multiarray_umath import ndarray
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from plot import plotFeatureImportance
from scipy.stats import pearsonr
# from run_model import getOLSModelDegree1, getOLSModelOneDegree2, getOLSModelTwoDegree2, getOLSModelDegree2, \
#     runStepwiseRegression, getMLresults, runDT, getMLresultsGBDT, getSubsampleResults
from run_model import neuralNetFeatureImportance,getMLresults, runDT, getMLresultsGBDT, getSubsampleResults, \
    getMLresultsRFLassoOls,getMLresultsNewX, getMLresultsGBDTNewX,linearReg,lassoSubsample,rfLassoSubsample,\
    GBLassoSubsample,NNLassoSubsample,OLSDegree2ResultsVector,getRfRfresultsNewX,getLassoRfResultsNewX,\
    getLassoLassoResultsNewX
from gen_data import genData
from process_data import genLongX,xFullidx
from plot import plotHist, plotDistribution
from utils import determineAxis, paramsLasso,hamming
import matplotlib.pyplot as plt
import time

print ('########################## Original DGP: gen X from normal+correlation=-0.3 ##################################')
np.random.seed(42)
noise_sigma = 0.7
sampleX, sampleY, gt_coef = genData(x_size=11,genCore='normal',func= '1',noise_sigma=noise_sigma,correlated=True)

########## select 3 features by RF #########
print '################### RF(top 3 features selected) + LASSO, ridge, linear with extra term in ols ################' + '\n'
getMLresultsNewX(sampleX,sampleY,XFsize=3,Psize=7)
