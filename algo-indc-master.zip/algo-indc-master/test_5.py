import numpy as np
from numpy.core._multiarray_umath import ndarray
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from plot import plotFeatureImportance
from scipy.stats import pearsonr
# from run_model import getOLSModelDegree1, getOLSModelOneDegree2, getOLSModelTwoDegree2, getOLSModelDegree2, \
#     runStepwiseRegression, getMLresults, runDT, getMLresultsGBDT, getSubsampleResults
from run_model import neuralNetFeatureImportance,getMLresults, runDT, getMLresultsGBDT, getSubsampleResults, \
    getMLresultsRFLassoOls,getMLresultsNewX, getMLresultsGBDTNewX,linearReg,lassoSubsample,rfLassoSubsample,\
    GBLassoSubsample,NNLassoSubsample,OLSDegree2ResultsVector,getRfRfresultsNewX,getLassoRfResultsNewX,\
    getLassoLassoResultsNewX
from gen_data import genData
from process_data import genLongX,xFullidx
from plot import plotHist, plotDistribution
from utils import determineAxis, paramsLasso,hamming
import matplotlib.pyplot as plt
import time

# Results for model variation 2: for full sample, non-overlapping subsample, and bootstrap sample
print ('################### gen X from normal+correlation=-0.3, gen Y from model variation 2 ##################################')
np.random.seed(42)
noise_sigma = 0.7
sampleX, sampleY, gt_coef = genData(x_size=12,genCore='normal2',func= 'variation2',noise_sigma=noise_sigma,correlated=True)

# For model variation2, delete x12 in sampleX
for row in sampleX:
    del row[-1]

print '################### RF + LASSO, ridge, linear with extra term in ols ################' + '\n'
getMLresultsNewX(sampleX,sampleY,XFsize=5,Psize=7)

print '################### Gradient boosting + LASSO, ridge, linear with extra term in ols ################' + '\n'
getMLresultsGBDTNewX(sampleX,sampleY,XFsize=5,Psize=7)

print '################### Neural Network + LASSO, ridge, linear with extra term in ols ################' + '\n'
neuralNetFeatureImportance(sampleX, sampleY, XFsize=5, Psize=7)

# DGP 2: Non overlapping subsample' heat map plots
rfLassoSubsample(sampleX,sampleY,XFsize=5,Psize=7,method='kfold')
GBLassoSubsample(sampleX,sampleY,XFsize=5,Psize=7, method='kfold')
NNLassoSubsample(sampleX,sampleY,XFsize=5,Psize=7,method='kfold')

# DGP 2: bootstrap samples' heatmap
rfLassoSubsample(sampleX,sampleY,XFsize=5,Psize=7,method='bootstrap')
GBLassoSubsample(sampleX,sampleY,XFsize=5,Psize=7, method='bootstrap')
NNLassoSubsample(sampleX,sampleY,XFsize=5,Psize=7,method='bootstrap')

